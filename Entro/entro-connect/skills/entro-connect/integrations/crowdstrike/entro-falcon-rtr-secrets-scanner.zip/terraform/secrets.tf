# ── Falcon API secret (pre-created in your AWS account) ─────────────────────
# Expected JSON: { "clientId": "...", "clientSecret": "...", "baseUrl": "..." }

data "aws_secretsmanager_secret" "crowdstrike" {
  arn = var.crowdstrike_secret_arn
}

# ── Entro secret (create new or reference existing) ──────────────────────────

resource "aws_secretsmanager_secret" "entro" {
  count = var.create_entro_secret ? 1 : 0

  name                    = local.entro_secret
  description             = "Entro Security API credentials for RTR secret scanning"
  recovery_window_in_days = var.secret_recovery_window_days
}

resource "aws_secretsmanager_secret_version" "entro" {
  count = var.create_entro_secret ? 1 : 0

  secret_id = aws_secretsmanager_secret.entro[0].id
  secret_string = jsonencode({
    entroApiKey = var.entro_api_key
    entroApiUrl = var.entro_api_url
  })
}

data "aws_secretsmanager_secret" "entro_existing" {
  count = var.create_entro_secret ? 0 : 1
  arn   = var.existing_entro_secret_arn
}

# ── Unified locals ───────────────────────────────────────────────────────────

locals {
  crowdstrike_secret_arn = data.aws_secretsmanager_secret.crowdstrike.arn
  entro_secret_arn       = var.create_entro_secret ? aws_secretsmanager_secret.entro[0].arn : data.aws_secretsmanager_secret.entro_existing[0].arn
}
