terraform {
  required_version = ">= 1.5"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    null = {
      source  = "hashicorp/null"
      version = "~> 3.0"
    }
  }

  # Uncomment to store state remotely in S3:
  # backend "s3" {
  #   bucket = "your-tfstate-bucket"
  #   key    = "crowdstrike-rtr-scanning/terraform.tfstate"
  #   region = var.aws_region
  # }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = merge(
      { Project = var.project_name, ManagedBy = "terraform" },
      var.tags,
    )
  }
}

# ── Derived names (all from project_name) ────────────────────────────────────

locals {
  iam_role_name    = var.iam_role_name != "" ? var.iam_role_name : var.project_name
  entro_secret     = var.entro_secret_name != "" ? var.entro_secret_name : "${var.project_name}-entro"
  log_group        = var.log_group != "" ? var.log_group : "/${var.project_name}"
}
