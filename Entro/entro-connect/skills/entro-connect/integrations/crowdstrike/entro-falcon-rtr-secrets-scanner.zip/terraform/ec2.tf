# ── EC2 deployment (deploy_ec2 = true) ───────────────────────────────────────
#
# Deploys the scanner to an EC2 instance. Optional SSH from a single CIDR for break-glass access.
# The instance reads your Falcon and Entro API credentials from Secrets Manager at runtime.
# systemd: entro-rtr-scanner.service + entro-rtr-scanner.timer; wrapper /usr/local/bin/run-entro-rtr-scanner.

# ── AMI: latest Amazon Linux 2023 ────────────────────────────────────────────

data "aws_ami" "al2023" {
  count       = var.deploy_ec2 ? 1 : 0
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-*-x86_64"]
  }
  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

# ── Default VPC / Subnet fallback ─────────────────────────────────────────────

data "aws_vpc" "default" {
  count   = var.deploy_ec2 && var.vpc_id == "" ? 1 : 0
  default = true
}

data "aws_subnets" "default" {
  count = var.deploy_ec2 && var.subnet_id == "" ? 1 : 0
  filter {
    name   = "vpc-id"
    values = [local.vpc_id]
  }
  filter {
    name   = "default-for-az"
    values = ["true"]
  }
}

locals {
  vpc_id    = var.vpc_id != "" ? var.vpc_id : try(data.aws_vpc.default[0].id, "")
  subnet_id = var.subnet_id != "" ? var.subnet_id : try(data.aws_subnets.default[0].ids[0], "")
}

# ── Security group: SSH from your IP only ─────────────────────────────────────

resource "aws_security_group" "scanner" {
  count       = var.deploy_ec2 ? 1 : 0
  name        = "${var.project_name}-sg"
  description = "SSH from allowed CIDR only; all outbound for API calls"
  vpc_id      = local.vpc_id

  ingress {
    description = "SSH"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = [var.allowed_ssh_cidr]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# ── Instance profile (attaches the existing IAM role) ─────────────────────────

resource "aws_iam_instance_profile" "scanner" {
  count = var.deploy_ec2 ? 1 : 0
  name  = "${var.project_name}-profile"
  role  = aws_iam_role.scanner.name
}

# ── User data: install system deps + write .env ──────────────────────────────

locals {
  user_data = var.deploy_ec2 ? templatefile("${path.module}/templates/user_data.sh.tftpl", {
    crowdstrike_secret_arn = local.crowdstrike_secret_arn
    entro_secret_arn       = local.entro_secret_arn
    aws_region             = var.aws_region
    scan_file_types        = var.scan_file_types
    scan_paths_unix        = var.scan_paths_unix
    scan_max_size_kb       = var.scan_max_size_kb
    scan_max_depth         = var.scan_max_depth
    scan_os_types          = var.scan_os_types
    target_hosts           = var.target_hosts
    scan_all_hosts         = var.scan_all_hosts
    max_workers            = var.max_workers
    log_group              = local.log_group
  }) : ""

  scanner_service_unit = var.deploy_ec2 ? templatefile("${path.module}/templates/entro-rtr-scanner.service.tftpl", {
    extra_args = trimspace(var.scanner_systemd_extra_args)
  }) : ""

  scanner_timer_unit = var.deploy_ec2 ? templatefile("${path.module}/templates/entro-rtr-scanner.timer.tftpl", {
    on_calendar          = var.scanner_on_calendar
    randomized_delay_sec = var.scanner_randomized_delay_sec
  }) : ""
}

# ── EC2 instance ──────────────────────────────────────────────────────────────

resource "aws_instance" "scanner" {
  count = var.deploy_ec2 ? 1 : 0

  ami                         = data.aws_ami.al2023[0].id
  instance_type               = var.instance_type
  key_name                    = var.ssh_key_name
  subnet_id                   = local.subnet_id
  vpc_security_group_ids      = [aws_security_group.scanner[0].id]
  iam_instance_profile        = aws_iam_instance_profile.scanner[0].name
  associate_public_ip_address = true
  user_data                   = local.user_data

  root_block_device {
    volume_size = 30
    volume_type = "gp3"
    encrypted   = true
  }

  tags = {
    Name = var.project_name
  }
}

# ── CloudWatch log group ──────────────────────────────────────────────────────

resource "aws_cloudwatch_log_group" "scanner" {
  count             = var.deploy_ec2 ? 1 : 0
  name              = local.log_group
  retention_in_days = var.log_retention_days
}

# ── Elastic IP ────────────────────────────────────────────────────────────────

resource "aws_eip" "scanner" {
  count    = var.deploy_ec2 ? 1 : 0
  instance = aws_instance.scanner[0].id
  domain   = "vpc"
}

# ── Deploy script files via provisioner ──────────────────────────────────────
# Re-runs when entro_rtr_scanner.py changes (trigger on file hash).

resource "null_resource" "deploy_scanner" {
  count      = var.deploy_ec2 ? 1 : 0
  depends_on = [aws_instance.scanner]

  triggers = {
    script_hash = filesha256("${path.module}/../entro_rtr_scanner.py")
    instance_id = aws_instance.scanner[0].id
    run_wrapper_hash   = filesha256("${path.module}/templates/run-entro-rtr-scanner.sh")
    service_tftpl_hash = filesha256("${path.module}/templates/entro-rtr-scanner.service.tftpl")
    timer_tftpl_hash   = filesha256("${path.module}/templates/entro-rtr-scanner.timer.tftpl")
    scanner_schedule = sha256(jsonencode({
      timer_enabled        = var.scanner_timer_enabled
      on_calendar          = var.scanner_on_calendar
      randomized_delay_sec = var.scanner_randomized_delay_sec
      extra_args           = var.scanner_systemd_extra_args
      run_on_deploy        = var.scanner_run_on_deploy
    }))
  }

  connection {
    type        = "ssh"
    user        = "ec2-user"
    private_key = file(var.ssh_private_key_path)
    host        = aws_eip.scanner[0].public_ip
  }

  provisioner "remote-exec" {
    inline = ["cloud-init status --wait"]
  }

  provisioner "file" {
    source      = "${path.module}/../entro_rtr_scanner.py"
    destination = "/home/ec2-user/scanner/entro_rtr_scanner.py"
  }

  provisioner "file" {
    source      = "${path.module}/../requirements.txt"
    destination = "/home/ec2-user/scanner/requirements.txt"
  }

  provisioner "remote-exec" {
    inline = [
      "cd /home/ec2-user/scanner",
      "python3 -m venv venv",
      "source venv/bin/activate",
      "pip install --upgrade pip -q",
      "pip install -r requirements.txt -q",
    ]
  }

  provisioner "file" {
    content     = file("${path.module}/templates/run-entro-rtr-scanner.sh")
    destination = "/tmp/run-entro-rtr-scanner.sh.tf"
  }

  provisioner "file" {
    content     = local.scanner_service_unit
    destination = "/tmp/entro-rtr-scanner.service.tf"
  }

  provisioner "file" {
    content     = local.scanner_timer_unit
    destination = "/tmp/entro-rtr-scanner.timer.tf"
  }

  provisioner "remote-exec" {
    inline = [<<-EOT
      set -euo pipefail
      sudo cp /tmp/run-entro-rtr-scanner.sh.tf /usr/local/bin/run-entro-rtr-scanner
      sudo chmod +x /usr/local/bin/run-entro-rtr-scanner
      # Legacy wrapper filename from older releases
      for legacy in /usr/local/bin/run-scanner; do
        if [ -f "$legacy" ]; then
          sudo sed -i 's/scan_secrets\.py/entro_rtr_scanner.py/g; s/main\.py/entro_rtr_scanner.py/g' "$legacy" || true
        fi
      done
      # Remove previous unit names so only entro-rtr-scanner.* is active
      sudo systemctl stop entro-scanner.timer 2>/dev/null || true
      sudo systemctl disable entro-scanner.timer 2>/dev/null || true
      sudo rm -f /etc/systemd/system/entro-scanner.timer /etc/systemd/system/entro-scanner.service
      sudo systemctl stop entro-scanner.service 2>/dev/null || true
      sudo cp /tmp/entro-rtr-scanner.service.tf /etc/systemd/system/entro-rtr-scanner.service
      if ${var.scanner_timer_enabled ? "true" : "false"}; then
        sudo cp /tmp/entro-rtr-scanner.timer.tf /etc/systemd/system/entro-rtr-scanner.timer
      else
        sudo systemctl stop entro-rtr-scanner.timer 2>/dev/null || true
        sudo systemctl disable entro-rtr-scanner.timer 2>/dev/null || true
        sudo rm -f /etc/systemd/system/entro-rtr-scanner.timer
      fi
      sudo systemctl daemon-reload
      if ${var.scanner_timer_enabled ? "true" : "false"}; then
        sudo systemctl enable entro-rtr-scanner.timer
        sudo systemctl restart entro-rtr-scanner.timer || sudo systemctl start entro-rtr-scanner.timer
      fi
      if ${var.scanner_run_on_deploy ? "true" : "false"}; then
        sudo systemctl start --no-block entro-rtr-scanner.service
      fi
    EOT
    ]
  }
}
