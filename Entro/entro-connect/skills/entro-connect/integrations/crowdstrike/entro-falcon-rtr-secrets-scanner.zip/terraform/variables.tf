variable "project_name" {
  description = "Project name — all resource names are derived from this."
  type        = string
  default     = "crowdstrike-rtr-scanner"
}

variable "aws_region" {
  description = "AWS region to deploy resources into."
  type        = string
  default     = "us-east-1"
}

# ── Your Falcon API credentials secret (create in AWS before Terraform apply) ─
# JSON keys: clientId, clientSecret, baseUrl

variable "crowdstrike_secret_arn" {
  description = "ARN of a Secrets Manager secret in your account with your CrowdStrike Falcon API credentials (clientId, clientSecret, baseUrl)."
  type        = string
}

# ── Entro secret ──────────────────────────────────────────────────────────────

variable "create_entro_secret" {
  description = "Set to true to create a new secret for Entro API credentials."
  type        = bool
  default     = true
}

variable "existing_entro_secret_arn" {
  description = "ARN of an existing Entro secret (used when create_entro_secret = false)."
  type        = string
  default     = ""
}

variable "entro_secret_name" {
  description = "Name for the new Entro secret. Leave empty to derive from project_name."
  type        = string
  default     = ""
}

variable "secret_recovery_window_days" {
  description = "Days before a deleted secret is permanently removed (0 to disable recovery window)."
  type        = number
  default     = 7
}

variable "entro_api_key" {
  description = "Entro Security API key (used when create_entro_secret = true)."
  type        = string
  sensitive   = true
  default     = ""
}

variable "entro_api_url" {
  description = "Entro Security API endpoint."
  type        = string
  default     = "https://api.entro.security/v2/scan"
}

# ── IAM ──────────────────────────────────────────────────────────────────────

variable "iam_role_name" {
  description = "IAM role name. Leave empty to derive from project_name."
  type        = string
  default     = ""
}

variable "trusted_services" {
  description = "AWS service principals allowed to assume the scanner IAM role."
  type        = list(string)
  default     = ["lambda.amazonaws.com", "ec2.amazonaws.com", "ecs-tasks.amazonaws.com"]
}

# ── EC2 deployment ────────────────────────────────────────────────────────────

variable "deploy_ec2" {
  description = "Set to true to deploy the scanner on an EC2 instance."
  type        = bool
  default     = true
}

variable "instance_type" {
  description = "EC2 instance type. t3.micro is enough for the scanner."
  type        = string
  default     = "t3.micro"
}

variable "ssh_key_name" {
  description = "Name of an existing EC2 key pair for SSH access."
  type        = string
  default     = ""
}

variable "ssh_private_key_path" {
  description = "Local path to the SSH private key (used by provisioners to deploy files)."
  type        = string
  default     = "~/.ssh/id_rsa"
}

variable "allowed_ssh_cidr" {
  description = "CIDR block allowed to SSH into the instance (e.g. \"203.0.113.42/32\" for a single IP)."
  type        = string
  default     = ""
}

variable "vpc_id" {
  description = "VPC ID. Leave empty to use the default VPC."
  type        = string
  default     = ""
}

variable "subnet_id" {
  description = "Subnet ID (must be public for SSH). Leave empty to pick the first default-VPC subnet."
  type        = string
  default     = ""
}

# ── Scan configuration (baked into the instance .env) ─────────────────────────

variable "target_hosts" {
  description = "Comma-separated hostnames to scan when scan_all_hosts is false. Leave empty when scanning the full tenant (default)."
  type        = string
  default     = ""
}

variable "scan_all_hosts" {
  description = "When true (default), scan every host in your Falcon tenant (mac, linux, windows unless scan_os_types restricts)."
  type        = bool
  default     = true
}

variable "scan_file_types" {
  description = "Comma-separated file type globs to scan."
  type        = string
  default     = "*.json,*.env,*.env.*,*.yaml,*.yml,*.conf,*.config,*.properties,*.toml,*.ini,*.tfvars,*.tfvars.*"
}

variable "scan_paths_unix" {
  description = "Comma-separated paths to scan on Unix/macOS hosts."
  type        = string
  default     = "/home,/Users"
}

variable "scan_max_size_kb" {
  description = "Maximum file size to scan (KB)."
  type        = number
  default     = 250
}

variable "scan_max_depth" {
  description = "Maximum directory depth for find/Get-ChildItem."
  type        = number
  default     = 3
}

variable "scan_os_types" {
  description = "Comma-separated OS types to scan (e.g. \"mac,linux\"). Empty means all."
  type        = string
  default     = ""
}

variable "max_workers" {
  description = "Max concurrent host scans."
  type        = number
  default     = 20
}

variable "log_group" {
  description = "CloudWatch log group name. Leave empty to derive from project_name."
  type        = string
  default     = ""
}

variable "log_retention_days" {
  description = "CloudWatch log retention in days."
  type        = number
  default     = 30
}

# ── Scheduled scanner (systemd on EC2) ───────────────────────────────────────

variable "scanner_timer_enabled" {
  description = "Install and enable a systemd timer so scans run on a schedule without SSH or tmux."
  type        = bool
  default     = true
}

variable "scanner_on_calendar" {
  description = "systemd OnCalendar value (UTC). Examples: daily, *-*-* 03:00:00. See systemd.time(7)."
  type        = string
  default     = "*-*-* 02:00:00"
}

variable "scanner_randomized_delay_sec" {
  description = "Randomized delay (seconds) added to each timer fire to spread load. Use 0 to disable."
  type        = number
  default     = 300
}

variable "scanner_run_on_deploy" {
  description = "After apply, trigger one scan in the background (systemctl start --no-block). Terraform does not wait for it to finish."
  type        = bool
  default     = true
}

variable "scanner_systemd_extra_args" {
  description = "Extra CLI args for entro_rtr_scanner.py when started by systemd (e.g. --filter with quoting suitable for bash -lc)."
  type        = string
  default     = ""
  sensitive   = false
}

# ── Tagging ──────────────────────────────────────────────────────────────────

variable "tags" {
  description = "Additional tags to apply to all resources. Project tag is set automatically from project_name."
  type        = map(string)
  default     = {}
}
