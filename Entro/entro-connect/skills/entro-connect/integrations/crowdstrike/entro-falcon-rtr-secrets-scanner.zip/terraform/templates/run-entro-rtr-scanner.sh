#!/bin/bash
cd /home/ec2-user/scanner
source venv/bin/activate
exec python3 entro_rtr_scanner.py "$@"
