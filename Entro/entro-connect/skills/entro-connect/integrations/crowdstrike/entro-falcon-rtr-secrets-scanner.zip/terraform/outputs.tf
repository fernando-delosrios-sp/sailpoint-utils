output "crowdstrike_secret_arn" {
  description = "ARN of the Secrets Manager secret holding your Falcon API credentials (passed through from input)."
  value       = local.crowdstrike_secret_arn
}

output "entro_secret_arn" {
  description = "ARN of the Entro Secrets Manager secret."
  value       = local.entro_secret_arn
}

output "iam_role_arn" {
  description = "ARN of the IAM role."
  value       = aws_iam_role.scanner.arn
}

output "iam_role_name" {
  description = "Name of the IAM role."
  value       = aws_iam_role.scanner.name
}

# ── EC2 outputs ──────────────────────────────────────────────────────────────

output "instance_id" {
  description = "EC2 instance ID."
  value       = var.deploy_ec2 ? aws_instance.scanner[0].id : null
}

output "instance_public_ip" {
  description = "Elastic IP of the scanner instance."
  value       = var.deploy_ec2 ? aws_eip.scanner[0].public_ip : null
}

output "ssh_command" {
  description = "SSH command to connect to the scanner instance."
  value       = var.deploy_ec2 ? "ssh -i ${var.ssh_private_key_path} ec2-user@${aws_eip.scanner[0].public_ip}" : null
}

output "run_scanner_command" {
  description = "Optional manual run via SSH (normally entro-rtr-scanner.timer runs scans)."
  value       = var.deploy_ec2 ? "sudo systemctl start --no-block entro-rtr-scanner.service   # or: run-entro-rtr-scanner --all" : null
}

output "scanner_systemd_units" {
  description = "systemd units on the instance (names match entro_rtr_scanner.py)."
  value       = var.deploy_ec2 ? "entro-rtr-scanner.service (oneshot), entro-rtr-scanner.timer (schedule)" : null
}

output "scanner_timer_status_command" {
  description = "SSH command to inspect timer schedule and recent scanner journal lines."
  value       = var.deploy_ec2 ? "ssh -i ${var.ssh_private_key_path} ec2-user@${aws_eip.scanner[0].public_ip} 'systemctl list-timers entro-rtr-scanner.timer; journalctl -u entro-rtr-scanner.service -n 50 --no-pager'" : null
}

output "cloudwatch_log_group" {
  description = "CloudWatch log group for scanner logs."
  value       = var.deploy_ec2 ? local.log_group : null
}

output "redeploy_command" {
  description = "SCP command to manually update the script on the instance."
  value       = var.deploy_ec2 ? "scp -i ${var.ssh_private_key_path} entro_rtr_scanner.py ec2-user@${aws_eip.scanner[0].public_ip}:scanner/" : null
}
