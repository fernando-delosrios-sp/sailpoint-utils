#!/usr/bin/env python3
"""
entro_rtr_scanner.py — Scan endpoints for exposed secrets via Falcon Real Time Response (RTR)
and the Entro Security API.

Uses your Falcon API credentials and Entro API key. The scan script runs entirely on
each target host using only built-in tools:
  Unix/macOS : find + awk + curl + base64   (no python, no jq)
  Windows    : PowerShell built-ins only

Usage:
  python3 entro_rtr_scanner.py                          # from .env (SCAN_ALL_HOSTS=true → full tenant; else TARGET_HOST(S))
  python3 entro_rtr_scanner.py host1 host2              # explicit hosts
  python3 entro_rtr_scanner.py --all                    # every host in your Falcon tenant
  python3 entro_rtr_scanner.py --all --filter "platform_name:'Linux'"
"""

import base64
import json
import logging
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone

from dotenv import load_dotenv
from falconpy import Hosts, RealTimeResponse, RealTimeResponseAdmin

# ── logging ───────────────────────────────────────────────────────────────────

log = logging.getLogger("entro_rtr_scanner")
log.setLevel(logging.DEBUG)

_console = logging.StreamHandler(sys.stdout)
_console.setLevel(logging.INFO)
_console.setFormatter(logging.Formatter("%(message)s"))
log.addHandler(_console)

_log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
os.makedirs(_log_dir, exist_ok=True)
_log_file = os.path.join(_log_dir, f"scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
_fh = logging.FileHandler(_log_file)
_fh.setLevel(logging.DEBUG)
_fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
log.addHandler(_fh)

log.info(f"Log file: {_log_file}")

# ── credentials ───────────────────────────────────────────────────────────────

load_dotenv()

CLIENT_ID     = os.getenv("CROWDSTRIKE_CLIENT_ID")
CLIENT_SECRET = os.getenv("CROWDSTRIKE_CLIENT_SECRET")
BASE_URL      = os.getenv("CROWDSTRIKE_BASE_URL", "https://api.us-2.crowdstrike.com")
ENTRO_API_URL = os.getenv("ENTRO_API_URL", "https://api.entro.security/v2/scan")
ENTRO_API_KEY = os.getenv("ENTRO_API_KEY", "")

_aws_cs_secret   = os.getenv("AWS_CS_SECRET_ARN")
_aws_entro_secret = os.getenv("AWS_ENTRO_SECRET_ARN")
if _aws_cs_secret or _aws_entro_secret:
    try:
        import boto3
        _sm = boto3.client("secretsmanager", region_name=os.getenv("AWS_REGION", "us-east-1"))
        if _aws_cs_secret:
            _cs = json.loads(_sm.get_secret_value(SecretId=_aws_cs_secret)["SecretString"])
            CLIENT_ID     = _cs.get("clientId",     CLIENT_ID)
            CLIENT_SECRET = _cs.get("clientSecret", CLIENT_SECRET)
            BASE_URL      = _cs.get("baseUrl",      BASE_URL)
            log.info("Loaded Falcon API credentials from Secrets Manager")
        if _aws_entro_secret:
            _es = json.loads(_sm.get_secret_value(SecretId=_aws_entro_secret)["SecretString"])
            ENTRO_API_KEY = _es.get("entroApiKey", ENTRO_API_KEY)
            ENTRO_API_URL = _es.get("entroApiUrl", ENTRO_API_URL)
            log.info("Loaded Entro API credentials from Secrets Manager")
    except Exception as _e:
        log.warning(f"Secrets Manager load failed: {_e} — falling back to .env")

if not CLIENT_ID or not CLIENT_SECRET:
    log.error("Set CROWDSTRIKE_CLIENT_ID and CROWDSTRIKE_CLIENT_SECRET (your Falcon API client), or AWS_CS_SECRET_ARN.")
    sys.exit(1)
if not ENTRO_API_KEY:
    log.error("ENTRO_API_KEY not set — cannot scan without it.")
    sys.exit(1)

# ── scan filters ──────────────────────────────────────────────────────────────

SCAN_FILE_TYPES  = [t.strip() for t in os.getenv(
    "SCAN_FILE_TYPES",
    "*.json,*.env,*.env.*,*.yaml,*.yml,*.conf,*.config,*.properties,*.toml,*.ini,*.tfvars,*.tfvars.*"
).split(",") if t.strip()]

SCAN_PATHS_UNIX  = [p.strip() for p in os.getenv(
    "SCAN_PATHS_UNIX", "/home,/Users"
).split(",") if p.strip()]

SCAN_PATHS_WIN   = [p.strip() for p in os.getenv(
    "SCAN_PATHS_WIN", "C:\\Users,C:\\inetpub,C:\\app,C:\\ProgramData"
).split(",") if p.strip()]

SCAN_MAX_SIZE_KB = int(os.getenv("SCAN_MAX_SIZE_KB", "250"))
SCAN_MAX_DEPTH   = int(os.getenv("SCAN_MAX_DEPTH", "3"))

SCAN_OS_TYPES    = [t.strip().lower() for t in os.getenv(
    "SCAN_OS_TYPES", ""
).split(",") if t.strip()]

SCAN_EXCLUDE_UNIX = [p.strip() for p in os.getenv(
    "SCAN_EXCLUDE_UNIX",
    "*/node_modules/*,*/.npm/*,*/.cache/*,*/Library/*,*/.Trash/*,*/venv/*,*/.venv/*,"
    "*/.git/*,*/__pycache__/*,*/.cargo/*,*/.rustup/*,*/.nvm/*,"
    "*/vendor/*,*/.gradle/*,*/.m2/*,*/.tox/*,*/.pyenv/*"
).split(",") if p.strip()]

SCAN_EXCLUDE_WIN = [p.strip() for p in os.getenv(
    "SCAN_EXCLUDE_WIN",
    "*\\node_modules\\*,*\\AppData\\Local\\*,*\\.cache\\*,*\\.git\\*,"
    "*\\__pycache__\\*,*\\vendor\\*"
).split(",") if p.strip()]

SCAN_PARALLEL = int(os.getenv("SCAN_PARALLEL", "10"))  # concurrent curl calls per host

# ── tuning ────────────────────────────────────────────────────────────────────

MAX_WORKERS      = int(os.getenv("MAX_WORKERS",      "20"))
MAX_WAIT_TIME    = int(os.getenv("MAX_WAIT_TIME",    "1800"))  # per-host scan budget (seconds)
POLL_INTERVAL    = int(os.getenv("POLL_INTERVAL",    "5"))     # RTR command-status check interval
BG_POLL_INTERVAL = int(os.getenv("BG_POLL_INTERVAL", "20"))   # seconds between background scan checks


# ── remote script templates ───────────────────────────────────────────────────
# Raw strings — no f-string escaping. Placeholders are substituted at build time.
# Unix script accepts $1 as output file path. Workers append directly to it
# (bypasses stdout buffering from nohup). When $1 is empty (--local), uses stdout.

_UNIX_SCRIPT_TEMPLATE = r"""
ENTRO_URL="__ENTRO_URL__"
ENTRO_KEY="__ENTRO_KEY__"
MAX_JOBS=__PARALLEL__
_OUTFILE="${1:-}"

_emit() {
    if [ -n "$_OUTFILE" ]; then printf '%s\n' "$1" >> "$_OUTFILE"; else printf '%s\n' "$1"; fi
}
_emit "STATUS|INIT"

_HOST=$(hostname 2>/dev/null || printf 'N/A')
if [ "$(uname)" = "Darwin" ]; then
    _IP=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || printf 'N/A')
else
    _IP=$(hostname -I 2>/dev/null | awk '{print $1}' || printf 'N/A')
fi
_IP=${_IP:-N/A}

W=$(mktemp /tmp/.csw_XXXXXX.sh 2>/dev/null) || W="/tmp/.csw_$$.sh"
cat > "$W" << 'CSWORKER'
#!/bin/bash
f="$1"; EU="$2"; EK="$3"; MH="$4"; MI="$5"; _OF="$6"
BODY=$(mktemp 2>/dev/null) || exit 0
_FNAME=$(basename "$f")
if [ "$(uname)" = "Darwin" ]; then
    _OWN=$(stat -f "%Su"                          "$f" 2>/dev/null || printf 'N/A')
    _MT=$(stat -f "%Sm" -t "%Y-%m-%dT%H:%M:%SZ"  "$f" 2>/dev/null || printf 'N/A')
    _CT=$(stat -f "%SB" -t "%Y-%m-%dT%H:%M:%SZ"  "$f" 2>/dev/null || printf 'N/A')
else
    _OWN=$(stat -c "%U" "$f" 2>/dev/null || printf 'N/A')
    _MT=$(stat -c "%y" "$f" 2>/dev/null | awk '{print $1"T"$2}' | cut -d. -f1)
    _CT=$(stat -c "%w" "$f" 2>/dev/null | awk '{print $1"T"$2}' | cut -d. -f1)
    [ "${_CT:-}" = "-" ] && _CT=$(stat -c "%z" "$f" 2>/dev/null | awk '{print $1"T"$2}' | cut -d. -f1)
fi
_OWN=${_OWN:-N/A}; _MT=${_MT:-N/A}; _CT=${_CT:-N/A}
printf '{"data":"' > "$BODY"
awk '{ gsub(/\\/,"\\\\"); gsub(/"/,"\\\""); gsub(/\t/,"\\t"); gsub(/\r/,"\\r"); printf "%s\\n",$0 }' "$f" >> "$BODY" 2>/dev/null
printf '",' >> "$BODY"
printf '"exposed_metadata":{"ip_address":"%s","host_name":"%s","file_name":"%s","full_path":"%s","created_at":"%s","modified_at":"%s","owner":"%s"}}' \
    "$MI" "$MH" "$_FNAME" "$f" "$_CT" "$_MT" "$_OWN" >> "$BODY"
resp=$(curl -sf -X POST "$EU" -H "Authorization: $EK" -H "Content-Type: application/json" -H "accept: application/json" --data "@$BODY" --max-time 30 2>/dev/null)
rm -f "$BODY"
[ -z "$resp" ] && exit 0
cnt=$(printf '%s' "$resp" | grep -o '"totalCount":[0-9]*' | grep -o '[0-9]*$')
[ "${cnt:-0}" -gt 0 ] || exit 0
b64=$(printf '%s' "$resp" | base64 | tr -d '\n')
if [ -n "$_OF" ]; then
    printf 'FINDING|%s|%s|%s\n' "$f" "$_OWN" "$b64" >> "$_OF"
else
    printf 'FINDING|%s|%s|%s\n' "$f" "$_OWN" "$b64"
fi
CSWORKER
chmod +x "$W"

_FCOUNT=$(find __PATHS__ -maxdepth __MAX_DEPTH__ __PRUNE_EXPR__ -type f __FIND_EXPR__ -size -__MAX_KB__k 2>/dev/null | wc -l | tr -d ' ')
_emit "STATUS|FILES|${_FCOUNT}"

find __PATHS__ -maxdepth __MAX_DEPTH__ __PRUNE_EXPR__ -type f __FIND_EXPR__ -size -__MAX_KB__k -print0 2>/dev/null \
    | xargs -0 -P "$MAX_JOBS" -I{} bash "$W" {} "$ENTRO_URL" "$ENTRO_KEY" "$_HOST" "$_IP" "$_OUTFILE"

rm -f "$W" 2>/dev/null
_emit "SCAN_DONE"
"""

_WIN_SCRIPT_TEMPLATE = r"""
$scanPaths    = @(__PS_PATHS__) | Where-Object { Test-Path $_ }
$scanInclude  = @(__PS_INCLUDE__)
$scanMaxBytes = __MAX_BYTES__
$entroUrl     = "__ENTRO_URL__"
$entroKey     = "__ENTRO_KEY__"
$_HOST        = $env:COMPUTERNAME
$_IP          = try {
    (Get-NetIPAddress -AddressFamily IPv4 -EA Stop |
     Where-Object { $_.IPAddress -notmatch '^127\.' -and $_.PrefixOrigin -ne 'WellKnown' } |
     Select-Object -First 1).IPAddress
} catch { "N/A" }
if (-not $_IP) { $_IP = "N/A" }

$scanExclude = @(__PS_EXCLUDE__)
Get-ChildItem -Path $scanPaths -Recurse -Depth __MAX_DEPTH__ -Include $scanInclude -EA SilentlyContinue |
    Where-Object { $_.Length -le $scanMaxBytes } |
    Where-Object { $fp = $_.FullName; -not ($scanExclude | Where-Object { $fp -like $_ }) } |
    ForEach-Object {
    try {
        $content = Get-Content $_.FullName -Raw -EA Stop
        $owner   = try { (Get-Acl $_.FullName).Owner } catch { "N/A" }
        $body    = @{
            data             = $content
            exposed_metadata = @{
                ip_address  = $_IP
                host_name   = $_HOST
                file_name   = $_.Name
                full_path   = $_.FullName
                created_at  = $_.CreationTime.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
                modified_at = $_.LastWriteTime.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
                owner       = $owner
            }
        } | ConvertTo-Json -Compress -Depth 3
        $headers = @{ Authorization = $entroKey; accept = "application/json" }
        $resp    = Invoke-RestMethod -Uri $entroUrl -Method POST -TimeoutSec 30 `
                       -ContentType "application/json" -Headers $headers -Body $body
        if ($resp.totalCount -gt 0) {
            $respJson = $resp | ConvertTo-Json -Compress -Depth 10
            $b64      = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($respJson))
            Write-Output ("FINDING|" + $_.FullName + "|" + $owner + "|" + $b64)
        }
    } catch { }
}
Write-Output "SCAN_DONE"
"""


def _build_unix_script() -> str:
    find_name_expr = r" \( " + " -o ".join(f'-name "{t}"' for t in SCAN_FILE_TYPES) + r" \)"
    if SCAN_EXCLUDE_UNIX:
        prune_expr = (r"\( "
                      + " -o ".join(f'-path "{p}"' for p in SCAN_EXCLUDE_UNIX)
                      + r" \) -prune -o")
    else:
        prune_expr = ""
    return (
        _UNIX_SCRIPT_TEMPLATE
        .replace("__ENTRO_URL__", f"{ENTRO_API_URL}?generic=true&redact=true&aiClassification=true")
        .replace("__ENTRO_KEY__", ENTRO_API_KEY)
        .replace("__PATHS__",     " ".join(SCAN_PATHS_UNIX))
        .replace("__PRUNE_EXPR__", prune_expr)
        .replace("__FIND_EXPR__", find_name_expr)
        .replace("__MAX_KB__",    str(SCAN_MAX_SIZE_KB))
        .replace("__MAX_DEPTH__", str(SCAN_MAX_DEPTH))
        .replace("__PARALLEL__",  str(SCAN_PARALLEL))
    )


def _build_windows_script() -> str:
    return (
        _WIN_SCRIPT_TEMPLATE
        .replace("__ENTRO_URL__",  f"{ENTRO_API_URL}?generic=true&redact=true&aiClassification=true")
        .replace("__ENTRO_KEY__",  ENTRO_API_KEY)
        .replace("__PS_PATHS__",   ", ".join(f'"{p}"' for p in SCAN_PATHS_WIN))
        .replace("__PS_INCLUDE__", ", ".join(f'"{t}"' for t in SCAN_FILE_TYPES))
        .replace("__PS_EXCLUDE__", ", ".join(f'"{p}"' for p in SCAN_EXCLUDE_WIN))
        .replace("__MAX_BYTES__",  str(SCAN_MAX_SIZE_KB * 1024))
        .replace("__MAX_DEPTH__", str(SCAN_MAX_DEPTH))
    )


# ── background launcher / poll / cleanup command builders ────────────────────
#
# Strategy: write the scan script to a temp file via heredoc (no base64 — same
# command size as the original inline script), launch with nohup so it survives
# RTR's kill timer, then poll a second temp file for output.

def _build_unix_launcher_cmd() -> str:
    """Heredoc-based launcher: writes scan script to $SCRIPTFILE, runs it with
    nohup. The script itself writes directly to $OUTFILE (no stdout buffering)."""
    scan_script = _build_unix_script()
    script = (
        "SCRIPTFILE=$(mktemp /tmp/.cse_XXXXXX.sh 2>/dev/null || printf '/tmp/.cse_%s.sh' \"$$\")\n"
        "OUTFILE=$(mktemp /tmp/.cso_XXXXXX 2>/dev/null || printf '/tmp/.cso_%s' \"$$\")\n"
        "cat > \"$SCRIPTFILE\" << '__CS_SCAN_END__'\n"
        + scan_script +
        "\n__CS_SCAN_END__\n"
        "chmod +x \"$SCRIPTFILE\"\n"
        "touch \"$OUTFILE\"\n"
        "bash \"$SCRIPTFILE\" \"$OUTFILE\" > /dev/null 2>> \"$OUTFILE\" &\n"
        "disown $! 2>/dev/null\n"
        "printf 'SCAN_STARTED|%s|%s|%s\\n' \"$!\" \"$OUTFILE\" \"$SCRIPTFILE\"\n"
    )
    return f"runscript -Raw=```bash\n{script}\n```"


def _build_unix_poll_cmd(pid: str, outfile: str) -> str:
    script = (
        f"_OF='{outfile}'\n"
        "if grep -q '^SCAN_DONE' \"$_OF\" 2>/dev/null; then\n"
        "    printf 'STATUS|DONE\\n'\n"
        "    cat \"$_OF\"\n"
        "else\n"
        "    _L=$(wc -l < \"$_OF\" 2>/dev/null | tr -d ' ')\n"
        "    _PEEK=$(head -5 \"$_OF\" 2>/dev/null | tr '\\n' ' ')\n"
        "    printf 'STATUS|RUNNING|%s|%s\\n' \"${_L:-0}\" \"${_PEEK}\"\n"
        "fi\n"
    )
    return f"runscript -Raw=```bash\n{script}\n```"


def _build_unix_cleanup_cmd(pid: str, outfile: str, scriptfile: str) -> str:
    script = f"kill {pid} 2>/dev/null; rm -f '{outfile}' '{scriptfile}' 2>/dev/null; true\n"
    return f"runscript -Raw=```bash\n{script}\n```"


def _build_win_launcher_cmd() -> str:
    """PowerShell here-string launcher for Windows."""
    scan_script = _build_windows_script()
    script = (
        "$outFile    = [IO.Path]::Combine($env:TEMP, 'cso_' + [Guid]::NewGuid().ToString('N') + '.txt')\r\n"
        "$scriptFile = [IO.Path]::Combine($env:TEMP, 'cse_' + [Guid]::NewGuid().ToString('N') + '.ps1')\r\n"
        "@'\r\n"
        + scan_script +
        "\r\n'@ | Out-File -FilePath $scriptFile -Encoding UTF8\r\n"
        "$job = Start-Job -ScriptBlock { param($sf,$of) powershell -NoProfile -NonInteractive -File $sf 2>&1 | Out-File $of } -ArgumentList $scriptFile,$outFile\r\n"
        "Write-Output ('SCAN_STARTED|' + $job.Id + '|' + $outFile + '|' + $scriptFile)\r\n"
    )
    return f"runscript -Raw=```{script}```"


def _build_win_poll_cmd(job_id: str, outfile: str) -> str:
    script = (
        f"$raw = try {{ [IO.File]::ReadAllText('{outfile}') }} catch {{ '' }}\r\n"
        "if ($raw -match 'SCAN_DONE') { Write-Output 'STATUS|DONE'; Write-Output $raw }\r\n"
        "else { $n = if ($raw) { ($raw -split \"`n\").Count } else { 0 }; Write-Output ('STATUS|RUNNING|' + $n) }\r\n"
    )
    return f"runscript -Raw=```{script}```"


def _build_win_cleanup_cmd(job_id: str, outfile: str, scriptfile: str) -> str:
    script = (
        f"Stop-Job -Id {job_id} -EA SilentlyContinue\r\n"
        f"Remove-Job -Id {job_id} -Force -EA SilentlyContinue\r\n"
        f"Remove-Item -Path '{outfile}','{scriptfile}' -Force -EA SilentlyContinue\r\n"
    )
    return f"runscript -Raw=```{script}```"


# ── output parser ─────────────────────────────────────────────────────────────

def _parse_findings(stdout: str) -> list:
    """
    Parse FINDING|path|owner|base64(response) lines from script stdout.
    Returns a list of finding dicts.
    """
    findings = []
    for line in stdout.splitlines():
        if not line.startswith("FINDING|"):
            continue
        parts = line.split("|", 3)
        if len(parts) != 4:
            continue
        _, filepath, owner, b64 = parts
        try:
            response = json.loads(base64.b64decode(b64).decode("utf-8", errors="replace"))
        except Exception:
            continue
        findings.append({
            "file":        filepath.strip(),
            "owner":       owner.strip(),
            "total_count": response.get("totalCount", 0),
            "results":     response.get("results", []),
        })
    return findings


# ── RTR helpers ───────────────────────────────────────────────────────────────

def _api_call_with_backoff(fn, max_retries=5):
    """Call *fn()* and retry on 429 (rate limit) with exponential backoff."""
    for attempt in range(max_retries):
        res = fn()
        sc = res.get("status_code", 200)
        if sc != 429:
            return res
        wait = min(2 ** attempt + 1, 30)
        time.sleep(wait)
    return res  # return last response even if still 429


def _wait_for_command(rtr_admin: RealTimeResponseAdmin,
                      cloud_request_id: str,
                      timeout: int = 120) -> dict:
    """Poll RTR until the command reports complete=true."""
    start = time.time()
    while True:
        elapsed = time.time() - start
        if elapsed > timeout:
            raise TimeoutError(f"RTR command timed out after {timeout}s")
        res  = _api_call_with_backoff(
            lambda: rtr_admin.check_admin_command_status(
                cloud_request_id=cloud_request_id, sequence_id=0))
        rsrc = (res.get("body") or {}).get("resources") or []
        if rsrc and rsrc[0].get("complete"):
            if rsrc[0].get("errors"):
                raise RuntimeError(f"RTR command error: {rsrc[0]['errors']}")
            return rsrc[0]
        time.sleep(POLL_INTERVAL)


def _exec_rtr_cmd(rtr_admin: RealTimeResponseAdmin,
                  session_id: str,
                  cmd_str: str,
                  timeout: int = 120) -> dict:
    """Submit a runscript command and block until RTR marks it complete."""
    res = _api_call_with_backoff(
        lambda: rtr_admin.execute_admin_command(
            base_command="runscript", command_string=cmd_str, session_id=session_id))
    res_body = res.get("body") or {}
    res_rsrc = res_body.get("resources") or []
    if not res_rsrc:
        errs = res_body.get("errors") or []
        raise RuntimeError(
            f"runscript submission failed: "
            f"{errs[0].get('message') if errs else res.get('status_code')}")
    return _wait_for_command(rtr_admin, res_rsrc[0]["cloud_request_id"], timeout=timeout)


# ── host discovery ────────────────────────────────────────────────────────────

def query_all_hosts(fql_filter: str = None) -> list:
    """Return [{aid, hostname, platform_name}] for all (or filtered) hosts in your Falcon tenant."""
    client = Hosts(client_id=CLIENT_ID, client_secret=CLIENT_SECRET, base_url=BASE_URL)
    all_aids, offset = [], 0
    while True:
        params = {"limit": 500, "offset": offset}
        if fql_filter:
            params["filter"] = fql_filter
        result = client.query_devices_by_filter(**params)
        sc = result.get("status_code", 0)
        if sc == 401: raise RuntimeError("Authentication failed")
        if sc != 200: raise RuntimeError(f"Host query failed: HTTP {sc}")
        batch = result["body"].get("resources") or []
        all_aids.extend(batch)
        total = result["body"].get("meta", {}).get("pagination", {}).get("total", 0)
        if not batch or len(all_aids) >= total:
            break
        offset = len(all_aids)
    if not all_aids:
        return []
    devices = []
    for i in range(0, len(all_aids), 100):
        details = client.get_device_details(ids=all_aids[i : i + 100])
        for d in details["body"].get("resources") or []:
            devices.append({
                "aid":           d.get("device_id", ""),
                "hostname":      d.get("hostname", d.get("device_id", "")),
                "platform_name": d.get("platform_name", ""),
            })
    return devices


# ── per-host scan ─────────────────────────────────────────────────────────────

def scan_host(target_host: str, aid: str = None) -> dict:
    rtr       = RealTimeResponse(     client_id=CLIENT_ID, client_secret=CLIENT_SECRET, base_url=BASE_URL)
    rtr_admin = RealTimeResponseAdmin(client_id=CLIENT_ID, client_secret=CLIENT_SECRET, base_url=BASE_URL)
    hosts_api = Hosts(                client_id=CLIENT_ID, client_secret=CLIENT_SECRET, base_url=BASE_URL)

    # ── resolve AID + platform ────────────────────────────────────────────────
    if aid is None:
        hq = hosts_api.query_devices_by_filter(filter=f"hostname:'{target_host}'")
        sc = hq.get("status_code", 0)
        if sc == 401: raise RuntimeError("Authentication failed")
        if sc == 403: raise RuntimeError("Insufficient permissions")
        if sc != 200:
            errs = hq.get("body", {}).get("errors") or []
            raise RuntimeError(errs[0].get("message", f"HTTP {sc}") if errs else f"HTTP {sc}")
        resources = hq.get("body", {}).get("resources") or []
        if not resources:
            raise RuntimeError(f"Host not found in your Falcon tenant: '{target_host}'")
        aid = resources[0]

    details  = hosts_api.get_device_details(ids=[aid])
    device   = (details.get("body", {}).get("resources") or [{}])[0]
    platform = device.get("platform_name", "")
    is_win   = platform.lower() == "windows"
    log.info(f"{target_host}: platform={platform or 'unknown'}")

    if SCAN_OS_TYPES and platform.lower() not in SCAN_OS_TYPES:
        log.info(f"{target_host}: skipped (OS '{platform}' not in SCAN_OS_TYPES)")
        return {"host": target_host, "skipped": True, "platform": platform,
                "total_findings": 0, "findings": []}

    # ── open RTR session ──────────────────────────────────────────────────────
    init_res  = rtr.init_session(device_id=aid)
    init_body = init_res.get("body") or {}
    init_rsrc = init_body.get("resources") or []
    if not init_rsrc:
        errs = init_body.get("errors") or []
        msg  = errs[0].get("message", "unknown") if errs else f"HTTP {init_res.get('status_code')}"
        raise RuntimeError(f"RTR session failed: {msg}")
    session_id = init_rsrc[0]["session_id"]

    # ── Phase 1: write scan script to remote temp file via heredoc, launch nohup ─
    # The launcher runscript returns in ~2 s (foreground shell exits after nohup &).
    # The actual scan keeps running on the host regardless of RTR's kill timer.
    if is_win:
        launch_cmd = _build_win_launcher_cmd()
    else:
        launch_cmd = _build_unix_launcher_cmd()

    log.info(f"{target_host}: launching background scan on host...")
    launch_result = _exec_rtr_cmd(rtr_admin, session_id, launch_cmd, timeout=60)
    launch_out    = launch_result.get("stdout", "")

    started = next((l for l in launch_out.splitlines() if l.startswith("SCAN_STARTED|")), None)
    if not started:
        raise RuntimeError(f"Launcher produced no SCAN_STARTED line. stdout: {launch_out[:300]}")
    _, bg_pid, outfile, scriptfile = started.split("|", 3)
    log.info(f"{target_host}: scan running in background (PID {bg_pid})")

    # ── Phase 2: poll until SCAN_DONE or budget exhausted ───────────────────
    # RTR sessions expire after ~10 min of inactivity. If a poll command fails
    # with a session error, we transparently re-init and keep polling.
    scan_out      = ""
    scan_start    = time.time()
    poll_failures = 0
    while True:
        time.sleep(BG_POLL_INTERVAL)
        elapsed = time.time() - scan_start

        poll_cmd = (_build_win_poll_cmd(bg_pid, outfile) if is_win
                    else _build_unix_poll_cmd(bg_pid, outfile))
        try:
            poll_result = _exec_rtr_cmd(rtr_admin, session_id, poll_cmd, timeout=60)
            poll_failures = 0
        except Exception as poll_err:
            poll_failures += 1
            err_msg = str(poll_err).lower()
            if "session" in err_msg or "could not find" in err_msg:
                log.info(f"{target_host}: RTR session expired, re-initializing...")
                try:
                    new_init  = rtr.init_session(device_id=aid)
                    new_rsrc  = (new_init.get("body") or {}).get("resources") or []
                    if new_rsrc:
                        session_id = new_rsrc[0]["session_id"]
                        log.info(f"{target_host}: new session established")
                        continue
                except Exception:
                    pass
            if poll_failures >= 3:
                log.warning(f"{target_host}: poll failed 3 times in a row — aborting")
                break
            log.warning(f"{target_host}: poll error ({poll_err}), retrying...")
            continue

        poll_out    = poll_result.get("stdout", "")
        lines       = poll_out.splitlines()
        status_line = lines[0] if lines else ""

        if status_line.startswith("STATUS|DONE"):
            scan_out = "\n".join(lines[1:])
            log.info(f"{target_host}: scan completed after {elapsed:.0f}s")
            break
        elif status_line.startswith("STATUS|RUNNING"):
            parts = status_line.split("|")
            n = parts[2] if len(parts) > 2 else "?"
            peek = parts[3][:120] if len(parts) > 3 else ""
            extra = f"  [{peek}]" if peek else ""
            log.info(f"{target_host}: scanning... ({elapsed:.0f}s, {n} lines written){extra}")
        else:
            log.warning(f"{target_host}: unexpected poll response: {status_line[:120]}")

        if elapsed > MAX_WAIT_TIME:
            log.warning(f"{target_host}: MAX_WAIT_TIME ({MAX_WAIT_TIME}s) reached — collecting partial results")
            try:
                read_cmd    = (f"runscript -Raw=```Get-Content '{outfile}' -EA SilentlyContinue```"
                               if is_win else
                               f"runscript -Raw=```bash\ncat '{outfile}' 2>/dev/null\n```")
                read_result = _exec_rtr_cmd(rtr_admin, session_id, read_cmd, timeout=30)
                scan_out    = read_result.get("stdout", "")
            except Exception:
                pass
            break

    # ── Phase 3: cleanup temp files on the remote host ────────────────────────
    try:
        cleanup_cmd = (_build_win_cleanup_cmd(bg_pid, outfile, scriptfile) if is_win
                       else _build_unix_cleanup_cmd(bg_pid, outfile, scriptfile))
        _exec_rtr_cmd(rtr_admin, session_id, cleanup_cmd, timeout=30)
    except Exception:
        pass

    stdout = scan_out

    partial = "SCAN_DONE" not in stdout
    if partial:
        if not any(line.startswith("FINDING|") for line in stdout.splitlines()):
            raise RuntimeError("Script produced no output (launcher may have failed)")
        log.warning(f"{target_host}: results are partial (scan did not finish)")

    try:
        rtr.delete_session(session_id=session_id)
    except Exception:
        pass

    # ── parse and display findings ────────────────────────────────────────────
    findings       = _parse_findings(stdout)
    total_findings = sum(f["total_count"] for f in findings)

    if findings:
        log.info("=" * 100)
        log.info(f"  {target_host} — {len(findings)} file(s) with findings  ({total_findings} total)")
        log.info("=" * 100)
        for f in findings:
            log.warning(f"  {f['file']}  (owner: {f['owner']})")
            for r in f.get("results", []):
                ai = r.get("ai_insights") or {}
                log.info(f"      ▸ [{r.get('ai_classification','?')}] "
                         f"{r.get('origin','?')} | "
                         f"{ai.get('type','N/A')} — {ai.get('purpose','N/A')}")

    summary = {
        "host":           target_host,
        "scanned_at":     datetime.now(timezone.utc).isoformat(),
        "platform":       platform,
        "partial":        partial,
        "total_findings": total_findings,
        "findings":       findings,
    }

    tag = " (partial)" if partial else ""
    log.info(f"{target_host}: {total_findings} finding(s){tag}")
    return summary


# ── thread wrapper ────────────────────────────────────────────────────────────

def _run(hostname: str, aid: str = None) -> dict:
    try:
        return scan_host(hostname, aid=aid)
    except Exception as exc:
        log.warning(f"{hostname}: FAILED — {exc}")
        return {"host": hostname, "error": str(exc), "total_findings": 0}


# ── entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    args = sys.argv[1:]

    # ── --dump-script: print the fully-substituted bash script and exit ────────
    if "--dump-script" in args:
        log.info("# ── LAUNCHER (runscript wrapper) ──────────────────────────────")
        log.info(_build_unix_launcher_cmd()
                 .removeprefix("runscript -Raw=```bash\n")
                 .removesuffix("\n```"))
        log.info("")
        log.info("# ── SCAN SCRIPT (written to $SCRIPTFILE by the launcher) ──────")
        log.info(_build_unix_script())
        sys.exit(0)

    # ── --local: run the scan script directly on this machine (no RTR) ───────
    if "--local" in args:
        import subprocess, socket
        args = [a for a in args if a != "--local"]
        hostname = socket.gethostname()
        script_dir = os.path.dirname(os.path.abspath(__file__))
        out_path   = os.path.join(script_dir, "findings.json")
        log.info(f"Running scan locally on {hostname} (no RTR)...")
        log.info(f"Parallel workers: {SCAN_PARALLEL}")
        scan_script = _build_unix_script()

        collected_lines = []
        finding_count   = 0
        proc = subprocess.Popen(
            ["bash", "-c", scan_script],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        for line in proc.stdout:
            line = line.rstrip("\n")
            collected_lines.append(line)
            if line.startswith("FINDING|"):
                finding_count += 1
                parts = line.split("|", 3)
                fpath = parts[1] if len(parts) > 1 else "?"
                log.info(f"  [{finding_count}] FINDING: {fpath}")
            elif line == "SCAN_DONE":
                log.info(f"Scan complete — {finding_count} finding(s)")

        proc.wait()
        stderr = proc.stderr.read()
        if stderr:
            log.warning(f"stderr: {stderr[:500]}")

        stdout  = "\n".join(collected_lines)
        partial = "SCAN_DONE" not in stdout
        if partial:
            log.warning("Scan did not complete (no SCAN_DONE marker)")

        findings       = _parse_findings(stdout)
        total_findings = sum(f["total_count"] for f in findings)

        if findings:
            log.info("=" * 100)
            log.info(f"  {hostname} — {len(findings)} file(s) with findings  ({total_findings} total)")
            log.info("=" * 100)
            for f in findings:
                log.warning(f"  {f['file']}  (owner: {f['owner']})")
                for r in f.get("results", []):
                    ai = r.get("ai_insights") or {}
                    log.info(f"      ▸ [{r.get('ai_classification','?')}] "
                             f"{r.get('origin','?')} | "
                             f"{ai.get('type','N/A')} — {ai.get('purpose','N/A')}")

        summary = {
            "host":           hostname,
            "scanned_at":     datetime.now(timezone.utc).isoformat(),
            "platform":       sys.platform,
            "partial":        partial,
            "total_findings": total_findings,
            "findings":       findings,
        }
        with open(out_path, "w") as fh:
            json.dump(summary, fh, indent=2, default=str)
        tag = " (partial)" if partial else ""
        log.info(f"{hostname}: {total_findings} finding(s){tag} → {out_path}")
        sys.exit(0)

    scan_all   = "--all" in args or os.getenv("SCAN_ALL_HOSTS", "").lower() == "true"
    args       = [a for a in args if a != "--all"]

    fql_filter = os.getenv("SCAN_HOST_FILTER") or None
    if "--filter" in args:
        idx        = args.index("--filter")
        fql_filter = args[idx + 1] if idx + 1 < len(args) else None
        args       = [a for i, a in enumerate(args) if i not in (idx, idx + 1)]

    if scan_all:
        if SCAN_OS_TYPES and not fql_filter:
            vals = ",".join(f"'{t.capitalize()}'" for t in SCAN_OS_TYPES)
            fql_filter = f"platform_name:[{vals}]"
        elif SCAN_OS_TYPES and fql_filter:
            vals = ",".join(f"'{t.capitalize()}'" for t in SCAN_OS_TYPES)
            fql_filter = f"{fql_filter}+platform_name:[{vals}]"
        qualifier = f" (filter: {fql_filter})" if fql_filter else ""
        log.info(f"Querying all hosts from Falcon{qualifier}...")
        devices = query_all_hosts(fql_filter=fql_filter)
        if not devices:
            log.error("No hosts returned. Check your Falcon API credentials and filter.")
            sys.exit(1)
        target_pairs = [(d["hostname"], d["aid"]) for d in devices]
    elif args:
        target_pairs = [(h, None) for h in args]
    elif os.getenv("TARGET_HOSTS"):
        target_pairs = [(h.strip(), None)
                        for h in os.getenv("TARGET_HOSTS").split(",") if h.strip()]
    else:
        target_pairs = [(os.getenv("TARGET_HOST", "localhost"), None)]

    n = len(target_pairs)
    log.info(f"Targets: {n} host(s)" + (f" — {', '.join(h for h,_ in target_pairs)}" if n <= 10 else ""))
    log.info(f"Concurrency: {min(n, MAX_WORKERS)} workers")

    # ── run scans ─────────────────────────────────────────────────────────────
    run_start = time.time()
    if n == 1:
        results = [_run(*target_pairs[0])]
    else:
        workers = min(n, MAX_WORKERS)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(_run, h, a): h for h, a in target_pairs}
            results = []
            for f in as_completed(futures):
                results.append(f.result())
                done = len(results)
                if done % 50 == 0 or done == n:
                    log.info(f"Progress: {done}/{n} hosts done")
    run_elapsed = time.time() - run_start

    # ── output: single directory with per-host JSONs + aggregate report ───────
    timestamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              f"scan_{timestamp}")
    os.makedirs(output_dir, exist_ok=True)

    for r in results:
        host = r.get("host", "unknown").replace("/", "_")
        with open(os.path.join(output_dir, f"{host}.json"), "w") as fh:
            json.dump(r, fh, indent=2, default=str)

    failed              = [r for r in results if "error" in r]
    hosts_with_findings = [r for r in results if r.get("total_findings", 0) > 0]
    total_findings      = sum(r.get("total_findings", 0) for r in results)

    aggregate = {
        "scan_started":       datetime.now(timezone.utc).isoformat(),
        "duration_seconds":   round(run_elapsed),
        "hosts_total":        n,
        "hosts_scanned":      n - len(failed),
        "hosts_failed":       len(failed),
        "hosts_with_findings": len(hosts_with_findings),
        "total_findings":     total_findings,
        "hosts": [
            {"host": r.get("host"), "findings": r.get("total_findings", 0),
             "partial": r.get("partial", False), "error": r.get("error")}
            for r in sorted(results, key=lambda x: x.get("host", ""))
        ],
    }
    with open(os.path.join(output_dir, "_report.json"), "w") as fh:
        json.dump(aggregate, fh, indent=2, default=str)

    # ── console summary ──────────────────────────────────────────────────────
    log.info("=" * 100)
    log.info(f"SCAN SUMMARY  ({run_elapsed:.0f}s)")
    log.info("-" * 100)
    for r in sorted(results, key=lambda x: x.get("host", "")):
        host    = r.get("host", "?")
        partial = " (partial)" if r.get("partial") else ""
        if "error" in r:
            log.warning(f"  {host}: FAILED — {r['error']}")
        elif r.get("total_findings", 0) > 0:
            log.warning(f"  {host}: {r['total_findings']} finding(s){partial}")
        else:
            log.info(f"  [✓] {host}: clean{partial}")
    log.info("-" * 100)
    log.info(f"  Hosts scanned:       {n - len(failed)} / {n}")
    log.info(f"  Hosts with findings: {len(hosts_with_findings)}")
    log.info(f"  Total findings:      {total_findings}")
    log.info(f"  Output:              {output_dir}/")
    log.info("=" * 100)

    sys.exit(1 if failed else 0)
