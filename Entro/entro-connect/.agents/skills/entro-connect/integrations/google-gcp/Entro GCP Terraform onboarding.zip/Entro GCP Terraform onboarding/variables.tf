variable "organization_domain" {
  description = "The GCP Organization domain"
  type        = string
}

variable "project" {
  description = "The GCP project to use"
  type        = string
}

variable "region" {
  description = "The region to deploy resources"
  type        = string
  default     = "us-central1"
}

variable "zone" {
  description = "The zone to deploy resources"
  type        = string
  default     = "us-central1-a"
}

variable "gcp_services_to_enable_on_projects_list" {
  type = list(string)
  default = [
    "cloudresourcemanager.googleapis.com",
    "iam.googleapis.com",
    "recommender.googleapis.com",
  ]
}

variable "enable_services_on_all_projects" {
  description = "Whether to enable required services on all organization projects"
  type        = bool
  default     = true
}

variable "gcp_services_to_enable_on_host_project_list" {
  type = list(string)
  default = [
    "cloudresourcemanager.googleapis.com",
    "iam.googleapis.com",
    "recommender.googleapis.com",
    "policyanalyzer.googleapis.com",
    "pubsub.googleapis.com",
    "cloudasset.googleapis.com",
    "admin.googleapis.com",
    "drive.googleapis.com",
  ]
}

variable "gcp_enforcer_services" {
  type = list(string)
  default = [
    "run.googleapis.com",
    "cloudscheduler.googleapis.com",
    "cloudfunctions.googleapis.com",
    "cloudbuild.googleapis.com",
  ]
}

variable "gcp_billing_required_services_to_enable_list" {
  type = list(string)
  default = [
    "secretmanager.googleapis.com",
    "discoveryengine.googleapis.com",
  ]
}

variable "service_account_name" {
  description = "A service account name"
  type        = string
  default     = "entro-automatic-onboard"
}

variable "service_account_display_name" {
  description = "A service account display name"
  type        = string
  default     = "A service account for Entro Automatic Onboard"
}

variable "service_account_create_condition" {
  description = "Create service account or not"
  type        = bool
  default     = true
}

variable "service_account_key_create_condition" {
  description = "Create service account key or not"
  type        = bool
  default     = true
}

variable "service_account_grant_roles_condition" {
  description = "Grant roles for the service account or not"
  type        = bool
  default     = true
}

variable "gcp_roles_to_grant_list" {
  type = list(string)
  default = [
    "roles/logging.privateLogViewer",
    "roles/resourcemanager.organizationViewer",
    "roles/secretmanager.viewer",
    "roles/iam.supportUser",
    "roles/cloudfunctions.viewer",
    "roles/recommender.iamViewer",
    "roles/cloudasset.viewer",
    "roles/policyanalyzer.activityAnalysisViewer",
    "roles/iam.securityReviewer",
    "roles/resourcemanager.folderViewer",
    "roles/serviceusage.apiKeysViewer",
    "roles/discoveryengine.viewer",
  ]
}

variable "audit_log_configure_condition" {
  description = "Configure Audit Logs or not"
  type        = bool
  default     = true
}

variable "audit_log_all_services_condition" {
  description = "Enable Autdit Logs for all services in the organization or not"
  type        = bool
  default     = false
}

variable "gcp_services_to_audit_list" {
  type = list(string)
  default = [
    "secretmanager.googleapis.com",
    "cloudfunctions.googleapis.com",
    "iam.googleapis.com",
  ]
  validation {
    condition = alltrue([
      contains(var.gcp_services_to_audit_list, "secretmanager.googleapis.com"),
      contains(var.gcp_services_to_audit_list, "cloudfunctions.googleapis.com"),
      contains(var.gcp_services_to_audit_list, "iam.googleapis.com"),
      length(var.gcp_services_to_audit_list) >= 3
    ])
    error_message = "Enabling all logs for these services is mandatory: 'Secret Manager API', 'Cloud Functions API', and 'Identity and Access Management (IAM) API'."
  }
}

variable "enable_workload_identity_federation" {
  description = "Enable Workload Identity Federation"
  type        = bool
  default     = false
}

variable "workload_identity_pool_id" {
  description = "ID of the Workload Identity Pool"
  type        = string
  default     = "entro-idp-id"
}

variable "workload_identity_provider_id" {
  description = "ID of the Workload Identity Provider"
  type        = string
  default     = "entro-wip-id"
}

variable "aws_account_id" {
  description = "AWS Account ID"
  type        = string
  default     = "937217723901"
}

variable "aws_sts_arn" {
  description = "AWS Role Name"
  type        = string
  default     = ""
}

variable "use_billing_required_services" {
  description = "Enable billing required services"
  type        = bool
  default     = true
}

variable "create_enforcer" {
  description = "Whether to create the Entro Service Enforcer cloud function. the host project must have billing enabled!"
  type        = bool
  default     = false
}

variable "enforcer_only" {
  description = "When true and create_enforcer is true, disable API enabling via Terraform and let the enforcer handle it instead"
  type        = bool
  default     = false
}
