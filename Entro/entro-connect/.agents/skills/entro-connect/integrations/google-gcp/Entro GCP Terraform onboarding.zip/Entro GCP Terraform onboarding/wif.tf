resource "google_iam_workload_identity_pool" "pool" {
  count                     = var.enable_workload_identity_federation ? 1 : 0
  project                   = var.project
  workload_identity_pool_id = "${var.workload_identity_pool_id}-${random_integer.random_int.result}"
  display_name              = "Entro Production"
  description               = "Entro Production"
}

resource "google_iam_workload_identity_pool_provider" "provider" {
  count                              = var.enable_workload_identity_federation ? 1 : 0
  project                            = var.project
  workload_identity_pool_id          = google_iam_workload_identity_pool.pool[0].workload_identity_pool_id
  workload_identity_pool_provider_id = "${var.workload_identity_provider_id}-${random_integer.random_int.result}"
  display_name                       = "Entro workload provider"
  description                        = "This workload identity provider is used by Entro."
  attribute_condition                = "assertion.arn.startsWith(\"${var.aws_sts_arn}\")"
  aws {
    account_id = var.aws_account_id
  }
  attribute_mapping = {
    "google.subject"        = "assertion.arn"
    "attribute.aws_account" = "assertion.account"
  }
}

resource "google_service_account_iam_binding" "workload_identity_binding" {
  count              = var.service_account_create_condition && var.enable_workload_identity_federation ? 1 : 0
  service_account_id = google_service_account.this[0].name
  role               = "roles/iam.workloadIdentityUser"
  members = [
    "principalSet://iam.googleapis.com/${google_iam_workload_identity_pool.pool[0].name}/attribute.aws_account/${var.aws_account_id}"
  ]
}

output "wif_config" {
  value = var.enable_workload_identity_federation ? (
    <<-EOF
{
  "universe_domain": "googleapis.com",
  "type": "external_account",
  "audience": "//iam.googleapis.com/${google_iam_workload_identity_pool.pool[0].name}/providers/${google_iam_workload_identity_pool_provider.provider[0].workload_identity_pool_provider_id}",
  "subject_token_type": "urn:ietf:params:aws:token-type:aws4_request",
  "service_account_impersonation_url": "https://iamcredentials.googleapis.com/v1/projects/-/serviceAccounts/${google_service_account.this[0].email}:generateAccessToken",
  "token_url": "https://sts.googleapis.com/v1/token",
  "credential_source": {
    "environment_id": "aws1",
    "region_url": "http://169.254.169.254/latest/meta-data/placement/availability-zone",
    "url": "http://169.254.169.254/latest/meta-data/iam/security-credentials",
    "regional_cred_verification_url": "https://sts.{region}.amazonaws.com?Action=GetCallerIdentity&Version=2011-06-15"
  }
}
EOF
  ) : null
  description = "Outputs the workload identity federation config in JSON format suitable for console output."
}