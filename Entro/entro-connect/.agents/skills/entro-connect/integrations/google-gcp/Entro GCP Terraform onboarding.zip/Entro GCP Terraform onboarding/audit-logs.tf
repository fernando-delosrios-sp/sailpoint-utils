resource "google_organization_iam_audit_config" "this" {
  for_each = var.audit_log_configure_condition ? toset(var.gcp_services_to_audit_list) : []

  org_id  = data.google_organization.this.org_id
  service = each.key
  audit_log_config {
    log_type = "ADMIN_READ"
  }
  audit_log_config {
    log_type = "DATA_READ"
  }
  audit_log_config {
    log_type = "DATA_WRITE"
  }
}

resource "google_organization_iam_audit_config" "all" {
  count = var.audit_log_configure_condition && var.audit_log_all_services_condition ? 1 : 0

  org_id  = data.google_organization.this.org_id
  service = "allServices"
  audit_log_config {
    log_type = "ADMIN_READ"
  }
  audit_log_config {
    log_type = "DATA_READ"
  }
  audit_log_config {
    log_type = "DATA_WRITE"
  }
}
