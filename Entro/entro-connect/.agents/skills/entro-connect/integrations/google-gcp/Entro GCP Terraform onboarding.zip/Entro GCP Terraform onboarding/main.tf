################################################################################
# GCP / Data
################################################################################

data "google_organization" "this" {
  domain = var.organization_domain
}

data "google_projects" "org_projects" {
  filter = "parent.id:${data.google_organization.this.org_id}/*"
}

data "google_cloud_asset_search_all_resources" "gcloud_folder" {
  scope = "organizations/${data.google_organization.this.org_id}"
  asset_types = [
    "cloudresourcemanager.googleapis.com/Folder"
  ]
  query = "displayName:system-gsuite"
}

data "google_cloud_asset_search_all_resources" "all_projects" {
  scope = "organizations/${data.google_organization.this.org_id}"
  asset_types = [
    "cloudresourcemanager.googleapis.com/Project"
  ]
  query = "state:ACTIVE ${local.gsuite_folder_name != "" ? "AND NOT folders:${local.gsuite_folder_name}" : ""}"
}

locals {
  gsuite_folder_name = length(data.google_cloud_asset_search_all_resources.gcloud_folder.results) == 0 ? "" : split("/", data.google_cloud_asset_search_all_resources.gcloud_folder.results[0].name)[4]
  all_project_ids = [
    for resource in data.google_cloud_asset_search_all_resources.all_projects.results :
    split("/", resource.name)[4]
  ]
}