organization_domain  = "" # filled by you
project              = "" # filled by you
region               = "us-central1"
zone                 = "us-central1-a"
service_account_name = "" # filled by you

service_account_create_condition       = true
service_account_key_create_condition   = true
audit_log_all_services_condition = true
enable_workload_identity_federation = false
service_account_grant_roles_condition = true
use_billing_required_services = false
create_enforcer = false
enforcer_only = false 
enable_services_on_all_projects = true