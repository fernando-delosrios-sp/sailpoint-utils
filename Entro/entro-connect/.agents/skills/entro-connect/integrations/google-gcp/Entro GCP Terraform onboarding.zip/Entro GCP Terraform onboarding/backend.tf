terraform {
  backend "gcs" {
    bucket = "entro-onboarding-terraform-state"
    prefix = "terraform/state/wif-setup"
  }
}
