resource "google_organization_iam_custom_role" "custom_role" {
  org_id      = data.google_organization.this.org_id
  role_id     = "entroLoggingRole_${random_integer.random_int.result}"
  title       = "Entro Logging Role"
  description = "This role is used by entro to access logging resources."
  permissions = [
    "logging.buckets.get",
    "logging.buckets.list",
    "logging.exclusions.get",
    "logging.exclusions.list",
    "logging.links.get",
    "logging.links.list",
    "logging.locations.get",
    "logging.locations.list",
    "logging.logEntries.download",
    "logging.logEntries.list",
    "logging.logMetrics.get",
    "logging.logMetrics.list",
    "logging.logServiceIndexes.list",
    "logging.logServices.list",
    "logging.logs.list",
    "logging.operations.get",
    "logging.operations.list",
    "logging.privateLogEntries.list",
    "logging.queries.create",
    "logging.queries.delete",
    "logging.queries.get",
    "logging.queries.list",
    "logging.queries.listShared",
    "logging.queries.update",
    "logging.sinks.get",
    "logging.sinks.list",
    "logging.usage.get",
    "logging.views.access",
    "logging.views.get",
    "logging.views.list",
    "logging.views.listLogs",
    "logging.views.listResourceKeys",
    "logging.views.listResourceValues",
    "resourcemanager.organizations.get",
    "secretmanager.versions.access",
    "secretmanager.secrets.list",
    "secretmanager.versions.list",
    "secretmanager.locations.list",
    "secretmanager.secrets.getIamPolicy",
    "iam.serviceAccounts.list",
    "iam.serviceAccounts.get",
    "iam.serviceAccounts.getIamPolicy",
    "iam.serviceAccountKeys.get",
    "iam.serviceAccountKeys.list",
    "iam.roles.get",
    "cloudfunctions.functions.get",
    "cloudfunctions.functions.list",
    "cloudbuild.builds.get",
    "cloudbuild.builds.list",
    "cloudbuild.operations.get",
    "cloudbuild.operations.list",
    "recommender.iamPolicyInsights.get",
    "recommender.iamPolicyInsights.list",
    "recommender.iamPolicyLateralMovementInsights.get",
    "recommender.iamPolicyLateralMovementInsights.list",
    "recommender.iamPolicyRecommendations.get",
    "recommender.iamPolicyRecommendations.list",
    "recommender.iamPolicyRecommenderConfig.get",
    "recommender.iamServiceAccountInsights.get",
    "recommender.iamServiceAccountInsights.list",
    "recommender.locations.get",
    "recommender.locations.list",
    "recommender.cloudAssetInsights.get",
    "recommender.cloudAssetInsights.list",
    "resourcemanager.projects.get",
    "resourcemanager.projects.list",
    "cloudasset.assets.listResource",
    "cloudasset.assets.listIamPolicy",
    "cloudasset.assets.listOrgPolicy",
    "cloudasset.assets.listAccessPolicy",
    "cloudasset.assets.listOSInventories",
    "policyanalyzer.serviceAccountKeyLastAuthenticationActivities.query",
    "policyanalyzer.serviceAccountLastAuthenticationActivities.query",
    "serviceusage.quotas.get",
    "serviceusage.services.get",
    "serviceusage.services.list",
    "iam.roles.list",
    "resourcemanager.organizations.getIamPolicy",
    "resourcemanager.projects.getIamPolicy",
    "resourcemanager.folders.getIamPolicy",
    "resourcemanager.folders.get"
  ]
}

resource "google_organization_iam_member" "service_account_custom_role_binding" {
  org_id = data.google_organization.this.org_id
  role   = google_organization_iam_custom_role.custom_role.name
  member = "serviceAccount:${google_service_account.this[0].email}"
}

################################################################################
# GCP / IAM / Service account
################################################################################

resource "google_service_account" "this" {
  count = var.service_account_create_condition ? 1 : 0

  account_id   = var.service_account_name
  display_name = var.service_account_display_name
}

resource "google_service_account_key" "this" {
  count = var.service_account_create_condition && var.service_account_key_create_condition ? 1 : 0

  service_account_id = google_service_account.this[0].name
}


resource "google_organization_iam_member" "this" {
  for_each = var.service_account_create_condition && var.service_account_grant_roles_condition ? toset(var.gcp_roles_to_grant_list) : []
  org_id   = data.google_organization.this.org_id

  role   = each.key
  member = "serviceAccount:${google_service_account.this[0].email}"

  depends_on = [google_project_service.this]
}
