output "service_account_key" {
  value     = var.service_account_create_condition && var.service_account_key_create_condition ? base64decode(google_service_account_key.this[0].private_key) : ""
  sensitive = true
}
