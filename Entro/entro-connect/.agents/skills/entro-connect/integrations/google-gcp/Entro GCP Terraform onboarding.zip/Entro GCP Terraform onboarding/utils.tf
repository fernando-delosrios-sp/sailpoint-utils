resource "random_integer" "random_int" {
  min = 1
  max = 1000
}