import functions_framework
import os
import json
import logging
import concurrent.futures
import time
import random
import threading
import uuid
from google.cloud import resourcemanager_v3
from google.cloud import service_usage_v1
from google.cloud import asset_v1
import google.cloud.logging

# Rate limits per GCP Service Usage API quotas:
# LIST requests: 600/min = 10/sec
# GET requests: 600/min = 10/sec  
# POST (mutate/enable) requests: 60/min = 1/sec
LIST_REQUEST_RATE_LIMIT = 10.0
GET_REQUEST_RATE_LIMIT = 10.0
POST_REQUEST_RATE_LIMIT = 1.0

log_client = google.cloud.logging.Client()
log_client.setup_logging()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global correlation ID for the current run
_correlation_id = None

class CorrelationFilter(logging.Filter):
    """
    Filter that adds correlation_id to all log records as a label
    """
    def filter(self, record):
        if _correlation_id:
            # Add correlation_id as a label for Google Cloud Logging
            if not hasattr(record, 'labels'):
                record.labels = {}
            record.labels['correlation_id'] = _correlation_id
            # Also add to message for visibility
            record.msg = f"[correlation_id={_correlation_id}] {record.msg}"
        return True

# Add the filter to the logger
correlation_filter = CorrelationFilter()
logger.addFilter(correlation_filter)

def set_correlation_id(correlation_id):
    """
    Set the correlation ID for the current run - will be included in all log entries
    """
    global _correlation_id
    _correlation_id = correlation_id

# The reason we implement our own rate limiter is to reduce dependence on third party libraries.
class RateLimiter:
    def __init__(self, rate_per_second):
        self.rate = rate_per_second
        self.lock = threading.Lock()
        self.last_check = time.time()
        self.tokens = rate_per_second
        self.max_tokens = rate_per_second

    def wait(self):
        with self.lock:
            current_time = time.time()
            elapsed_secs = current_time - self.last_check
            self.last_check = current_time
            
            self.tokens += elapsed_secs * self.rate
            if self.tokens > self.max_tokens:
                self.tokens = self.max_tokens

            if self.tokens >= 1:
                self.tokens -= 1
                return
            
            wait_time = (1 - self.tokens) / self.rate
            self.tokens = 0
            
        time.sleep(wait_time)
        with self.lock:
             self.last_check = time.time()

# Separate rate limiters for LIST, GET, and POST operations
LIST_RATE_LIMITER = RateLimiter(LIST_REQUEST_RATE_LIMIT)
GET_RATE_LIMITER = RateLimiter(GET_REQUEST_RATE_LIMIT)
POST_RATE_LIMITER = RateLimiter(POST_REQUEST_RATE_LIMIT) 

class ProgressTracker:
    def __init__(self, total_tasks):
        self.total = total_tasks
        self.completed = 0
        self.lock = threading.Lock()
        
    def increment(self):
        with self.lock:
            self.completed += 1
            percentage = (self.completed / self.total) * 100
            if self.completed % 10 == 0 or self.completed == self.total:
                logger.info(f"Progress: {self.completed}/{self.total} ({percentage:.1f}%)")

rm_client = resourcemanager_v3.ProjectsClient()
folders_client = resourcemanager_v3.FoldersClient()
asset_client = asset_v1.AssetServiceClient()

def get_gsuite_folder_name(org_id):
    scope = org_id 
    query = "displayName:system-gsuite"
    asset_types = ["cloudresourcemanager.googleapis.com/Folder"]
    
    request = asset_v1.SearchAllResourcesRequest(
        scope=scope,
        query=query,
        asset_types=asset_types
    )

    for page in asset_client.search_all_resources(request=request):
        logger.info(f"Found GSuite candidate folder: {page.name}")
        
        parts = page.name.split("/")
        if len(parts) >= 5:
            return parts[4]
            
    return None

def get_projects():
    """
    Find the relevant projects using Cloud Asset Inventory, mirroring the Terraform logic.
    """
    logger.info("getting projects")
    
    org_id = 'organizations/' + os.environ.get("ORGANIZATION_ID", "")

    logger.info(f"Using Organization: {org_id}")

    gsuite_folder_name = get_gsuite_folder_name(org_id)
    
    
    query = "state:ACTIVE"
    if gsuite_folder_name:
        logger.info(f"found gsuite folder ID: {gsuite_folder_name}")
        query += f' AND NOT folders:folders/{gsuite_folder_name}'
    else:
        logger.warning("no gsuite folder found")

    logger.info(f"Asset Inventory query: {query}")
    
    asset_types = ["cloudresourcemanager.googleapis.com/Project"]
    request = asset_v1.SearchAllResourcesRequest(
        scope=org_id,
        query=query,
        asset_types=asset_types
    )

    projects = []
    try:
        for resource in asset_client.search_all_resources(request=request):
             parts = resource.name.split("/")
             if len(parts) >= 5:
                 project_id = parts[4]
                 projects.append(project_id)
                 
    except Exception as e:
        logger.error(f"Error searching projects via Asset Inventory: {e}")
        return []
        
    logger.info(f"found {len(projects)} projects")
    return projects

def get_required_services():
    """
    Get the services to enable from env vars
    """
    raw = os.environ.get("REQUIRED_SERVICES", "")
    if not raw:
        logger.warning("no required services configured")
        return []
    logger.info(f"got {len(raw.split(','))} required services")
    return [s.strip() for s in raw.split(",") if s.strip()]

def enable_services_for_project(project_id, services, progress_tracker=None):
    """
    Enables services for a project
    Uses ListServices API first to efficiently check multiple services, then falls back to GetServiceRequest
    """
    logger.info(f"enabling services for project: {project_id}")
    su_client = service_usage_v1.ServiceUsageClient()
    enabled_count = 0
    errors = []
    max_retries = 5
    base_delay = 2

    # First, try to get all enabled services using ListServices API (more efficient)
    # This uses "List enabled services requests per minute" quota instead of individual GET requests
    enabled_services_set = set()
    list_services_success = False
    
    parent = f"projects/{project_id}"
    list_request = service_usage_v1.ListServicesRequest(
        parent=parent,
        filter="state:ENABLED"
    )
    
    for list_attempt in range(max_retries):
        try:
            LIST_RATE_LIMITER.wait()
            list_response = su_client.list_services(request=list_request)
            
            # Extract service names from the list
            for service_obj in list_response.services:
                # Service name format is "projects/{project}/services/{service_id}"
                # Extract just the service_id part
                service_name_parts = service_obj.name.split("/")
                if len(service_name_parts) >= 3:
                    service_id = service_name_parts[-1]
                    enabled_services_set.add(service_id)
            
            list_services_success = True
            logger.info(f"Listed {len(enabled_services_set)} enabled services for project {project_id}")
            break
        except Exception as e:
            is_rate_limit = "429" in str(e) or "Quota exceeded" in str(e)
            if is_rate_limit and list_attempt < max_retries - 1:
                sleep_time = base_delay * (2 ** list_attempt) + random.uniform(0, 1)
                logger.warning(f"Rate limit on ListServices for {project_id} (attempt {list_attempt+1}/{max_retries}). Retrying in {sleep_time:.2f}s... Error: {str(e)}")
                time.sleep(sleep_time)
                continue
            else:
                # ListServices failed, will fall back to individual GET requests
                logger.warning(f"Could not list services for {project_id}: {str(e)}. Will use individual GET requests.")
                break

    # Process each required service
    for service in services:
        service_name = f"projects/{project_id}/services/{service}"
        logger.info(f"enabling service: {service_name} for project: {project_id}")
        
        service_enabled = False
        
        # Check if service is in the enabled services set (from ListServices)
        if list_services_success and service in enabled_services_set:
            logger.info(f"service {service_name} already enabled for project: {project_id} (from list)")
            service_enabled = True
        else:
            # Fall back to individual GetServiceRequest if ListServices didn't work or service not found
            get_request = service_usage_v1.GetServiceRequest(name=service_name)
            
            for get_attempt in range(max_retries):
                try:
                    GET_RATE_LIMITER.wait()
                    service_obj = su_client.get_service(request=get_request)
                    
                    # `service.state` is an enum; different library versions expose the enum
                    # class differently, so avoid relying on `Service.State.ENABLED`.
                    state_name = getattr(service_obj.state, "name", str(service_obj.state))
                    if state_name == "ENABLED":
                        logger.info(f"service {service_name} already enabled for project: {project_id}")
                        service_enabled = True
                        break
                    else:
                        # Service exists but not enabled, proceed to enable
                        break
                except Exception as e:
                    is_rate_limit = "429" in str(e) or "Quota exceeded" in str(e)
                    if is_rate_limit and get_attempt < max_retries - 1:
                        sleep_time = base_delay * (2 ** get_attempt) + random.uniform(0, 1)
                        logger.warning(f"Rate limit on GET for {service_name} on {project_id} (attempt {get_attempt+1}/{max_retries}). Retrying in {sleep_time:.2f}s... Error: {str(e)}")
                        time.sleep(sleep_time)
                        continue
                    else:
                        # Non-rate-limit error or final attempt failed, log and proceed to enable
                        logger.warning(f"Could not determine state of {service_name} on {project_id}: {str(e)}. Proceeding to enable.")
                        break
        
        # If service is already enabled, skip to next service
        if service_enabled:
            if progress_tracker:
                progress_tracker.increment()
            continue
        
        # Service not enabled, proceed to enable it (POST request with retry)
        for attempt in range(max_retries):
            try:
                # Use POST rate limiter for write operations (more conservative rate)
                POST_RATE_LIMITER.wait()
                request = service_usage_v1.EnableServiceRequest(
                    name=service_name
                )
                operation = su_client.enable_service(request=request)
                operation.result(timeout=60)
                enabled_count += 1
                logger.info(f"enabled service: {service_name} for project: {project_id}")
                break
            except Exception as e:
                is_rate_limit = "429" in str(e) or "Quota exceeded" in str(e) or "Service Usage API has not been used" in str(e)
                if is_rate_limit and attempt < max_retries - 1:
                    sleep_time = base_delay * (2 ** attempt) + random.uniform(0, 1)
                    logger.warning(f"Rate limit/Error enabling {service} on {project_id} (attempt {attempt+1}/{max_retries}). Retrying in {sleep_time:.2f}s... Error: {str(e)}")
                    time.sleep(sleep_time)
                    continue
                
                if attempt == max_retries - 1 or not is_rate_limit:
                    error_msg = f"Failed to enable {service} on {project_id}: {str(e)}"
                    logger.error(error_msg)
                    errors.append(error_msg)
        
        # Increment progress tracker after processing this service (whether enabled or failed)
        if progress_tracker:
            progress_tracker.increment()

    logger.info(f"finished enabling services for project: {project_id}")
    return enabled_count, errors

@functions_framework.http
def enforce_services(request):
    correlation_id = str(uuid.uuid4())
    # Set correlation ID in logger base config - will be included in all log entries
    set_correlation_id(correlation_id)
    
    logger.info("starting to enforce services...")

    required_services = get_required_services()
    if not required_services:
         return json.dumps({"correlation_id": correlation_id, "message": "No required services configured."}), 200

    try:
        all_projects = get_projects()
        logger.info(f"Found {len(all_projects)} projects")
    except Exception as e:
        logger.error(f"Failed to list projects: {e}")
        return json.dumps({"correlation_id": correlation_id, "error": f"Failed to list projects: {e}"}), 500

    total_enabled = 0
    errors = []

    total_tasks = len(all_projects) * len(required_services)
    tracker = ProgressTracker(total_tasks)
    logger.info(f"Total operations to perform: {total_tasks}")

    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        future_to_project = {
            executor.submit(enable_services_for_project, project_id, required_services, tracker): project_id
            for project_id in all_projects
        }

        for future in concurrent.futures.as_completed(future_to_project):
            project_id = future_to_project[future]
            try:
                enabled_count, project_errors = future.result()
                total_enabled += enabled_count
                errors.extend(project_errors)
            except Exception as e:
                logger.error(f"Exception processing project {project_id}: {e}")
                errors.append(f"Project {project_id} failed: {e}")

    summary = {
        "correlation_id": correlation_id,
        "projects_scanned": len(all_projects),
        "services_enforced_count": total_enabled,
        "top_10_errors": errors[:10]
    }
    
    logger.info(f"enforcement complete: {json.dumps(summary)}")
    
    return json.dumps(summary), 200



