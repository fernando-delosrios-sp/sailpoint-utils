

locals {
  projects_services = flatten([
    for projectId in local.all_project_ids : [
      for service in var.gcp_services_to_enable_on_projects_list : {
        project = projectId
        service = service
      }
    ]
  ])
  projects_billing_services = var.use_billing_required_services ? flatten([
    for projectId in local.all_project_ids : [
      var.use_billing_required_services ? flatten([
        for service in var.gcp_billing_required_services_to_enable_list : {
          project = projectId
          service = service
        }
      ]) : []
    ]
  ]) : []
}

resource "google_project_service" "this" {
  for_each = var.enable_services_on_all_projects && !(var.create_enforcer && var.enforcer_only) ? { for ps in local.projects_services : "${ps.project}_${ps.service}" => ps } : {}

  project            = each.value.project
  service            = each.value.service
  disable_on_destroy = false
}

resource "google_project_service" "host_project_services" {
  for_each = toset(var.gcp_services_to_enable_on_host_project_list)

  project            = var.project
  service            = each.value
  disable_on_destroy = false
}

resource "google_project_service" "enforcer_project_services" {
  for_each = var.create_enforcer ? toset(var.gcp_enforcer_services) : []

  project            = var.project
  service            = each.value
  disable_on_destroy = false
}


resource "google_project_service" "billing_required" {
  for_each = var.enable_services_on_all_projects && var.use_billing_required_services ? { for ps in local.projects_billing_services : "${ps.project}_${ps.service}" => ps } : {}

  project            = each.value.project
  service            = each.value.service
  disable_on_destroy = false

  depends_on = [
    google_project_service.this
  ]
}