################################################################################
# Source code
################################################################################
data "archive_file" "enforcer_zip" {
  count       = var.create_enforcer ? 1 : 0
  type        = "zip"
  source_dir  = "${path.module}/function_source"
  output_path = "${path.module}/enforcer.zip"
}

resource "google_storage_bucket" "function_bucket" {
  count                       = var.create_enforcer ? 1 : 0
  name                        = "entro-enforcer-source-${var.project}"
  location                    = var.region
  project                     = var.project
  uniform_bucket_level_access = true
  force_destroy               = true
}

resource "google_storage_bucket_object" "function_zip" {
  count  = var.create_enforcer ? 1 : 0
  name   = "enforcer-${data.archive_file.enforcer_zip[0].output_md5}.zip"
  bucket = google_storage_bucket.function_bucket[0].name
  source = data.archive_file.enforcer_zip[0].output_path
}

################################################################################
# Cloud Function to enforce services
################################################################################

// Service account
resource "google_service_account" "enforcer_agent" {
  count        = var.create_enforcer ? 1 : 0
  project      = var.project
  account_id   = "entro-enforcer-agent"
  display_name = "Service Account for Entro Enforcer Function"
}

// role
resource "google_organization_iam_custom_role" "enforcer_role" {
  count       = var.create_enforcer ? 1 : 0
  org_id      = data.google_organization.this.org_id
  role_id     = "entro_enforcer_role_${random_integer.random_int.result}"
  title       = "Entro Enforcer Role"
  description = "Minimal role for the Entro Service Enforcer"
  permissions = [
    "resourcemanager.projects.get",
    "resourcemanager.projects.list",
    "resourcemanager.folders.get",
    "resourcemanager.folders.list",
    "serviceusage.services.enable",
    "serviceusage.services.get",
    "serviceusage.services.list",
    "cloudasset.assets.searchAllResources"
  ]
}

// attaching the role to the service account
resource "google_organization_iam_member" "enforcer_agent_binding" {
  count  = var.create_enforcer ? 1 : 0
  org_id = data.google_organization.this.org_id
  role   = google_organization_iam_custom_role.enforcer_role[0].name
  member = "serviceAccount:${google_service_account.enforcer_agent[0].email}"
}

resource "google_project_iam_member" "enforcer_logging" {
  count   = var.create_enforcer ? 1 : 0
  project = var.project
  role    = "roles/logging.logWriter"
  member  = "serviceAccount:${google_service_account.enforcer_agent[0].email}"
}


// The function itself
resource "google_cloudfunctions2_function" "enforcer" {
  count       = var.create_enforcer ? 1 : 0
  name        = "entro-service-enforcer"
  location    = var.region
  description = "Ensures mandatory APIs are enabled on all projects"

  build_config {
    runtime     = "python311"
    entry_point = "enforce_services"
    source {
      storage_source {
        bucket = google_storage_bucket.function_bucket[0].name
        object = google_storage_bucket_object.function_zip[0].name
      }
    }
  }

  service_config {
    max_instance_count = 1
    available_memory   = "512M"
    timeout_seconds    = 3600

    service_account_email = google_service_account.enforcer_agent[0].email

    environment_variables = {
      REQUIRED_SERVICES = join(",", var.gcp_services_to_enable_on_projects_list)
      ORGANIZATION_ID   = data.google_organization.this.org_id
    }
  }

  depends_on = [
    google_project_service.enforcer_project_services,
    google_project_service.enforcer_project_services["cloudbuild.googleapis.com"],
  ]
}

################################################################################
# Scheduler
################################################################################
// service account
resource "google_service_account" "enforcer_invoker" {
  count        = var.create_enforcer ? 1 : 0
  project      = var.project
  account_id   = "entro-enforcer-invoker"
  display_name = "Scheduler Invoker for Entro Enforcer"
}

// attaching the run.invoker role to the service account
resource "google_cloud_run_service_iam_member" "invoker" {
  count    = var.create_enforcer ? 1 : 0
  project  = google_cloudfunctions2_function.enforcer[0].project
  location = google_cloudfunctions2_function.enforcer[0].location
  service  = google_cloudfunctions2_function.enforcer[0].name
  role     = "roles/run.invoker"
  member   = "serviceAccount:${google_service_account.enforcer_invoker[0].email}"
}

// scheduler
resource "google_cloud_scheduler_job" "enforcer_job" {
  count            = var.create_enforcer ? 1 : 0
  name             = "entro-enforcer-schedule"
  description      = "Triggers the service enforcer function every hour"
  schedule         = "0 */6 * * *"
  time_zone        = "Etc/UTC"
  attempt_deadline = "600s"

  http_target {
    http_method = "GET"
    uri         = google_cloudfunctions2_function.enforcer[0].service_config[0].uri

    oidc_token {
      service_account_email = google_service_account.enforcer_invoker[0].email
    }
  }
}



