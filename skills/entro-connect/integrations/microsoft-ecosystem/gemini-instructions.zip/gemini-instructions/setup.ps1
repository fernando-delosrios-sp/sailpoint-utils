#
# Entro MCP Audit Server - Gemini CLI Setup Script (Windows PowerShell)
# 
# This self-contained script configures Gemini CLI to use the Entro MCP audit server.
# 
# Usage:
#   1. Open PowerShell as Administrator (if needed)
#   2. Run: Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
#   3. Run: .\setup.ps1
#
# Or run directly:
#   powershell -ExecutionPolicy Bypass -File setup.ps1
#

$ErrorActionPreference = "Stop"

# Configuration
$MCP_SERVER_URL = "https://mcp.entro.security/mcp"
$SETTINGS_DIR = Join-Path $env:USERPROFILE ".gemini"
$SETTINGS_FILE = Join-Path $SETTINGS_DIR "settings.json"
$GEMINI_FILE = Join-Path $SETTINGS_DIR "GEMINI.md"

# Colors
function Write-ColorOutput($ForegroundColor) {
    $fc = $host.UI.RawUI.ForegroundColor
    $host.UI.RawUI.ForegroundColor = $ForegroundColor
    if ($args) {
        Write-Output $args
    }
    $host.UI.RawUI.ForegroundColor = $fc
}

Write-Host ""
Write-Host "╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║          Entro MCP Audit Server - Gemini Setup               ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Check if Gemini CLI is installed
Write-Host "Checking for Gemini CLI..." -ForegroundColor Yellow

$geminiCommand = Get-Command gemini -ErrorAction SilentlyContinue
if ($geminiCommand) {
    $GEMINI_PATH = $geminiCommand.Source
    Write-Host "✓ Gemini CLI found at: $GEMINI_PATH" -ForegroundColor Green
} else {
    Write-Host "✗ Gemini CLI not found. Please install it first:" -ForegroundColor Red
    Write-Host "  npm install -g @google/gemini-cli"
    exit 1
}

# Detect system information
Write-Host ""
Write-Host "Detecting system information..." -ForegroundColor Yellow

# Get hostname
$LOCAL_HOSTNAME = $env:COMPUTERNAME
if (-not $LOCAL_HOSTNAME) {
    $LOCAL_HOSTNAME = hostname
}
Write-Host "✓ Hostname: $LOCAL_HOSTNAME" -ForegroundColor Green

# Get username
$LOCAL_USERNAME = $env:USERNAME
if (-not $LOCAL_USERNAME) {
    $LOCAL_USERNAME = whoami
}
Write-Host "✓ Username: $LOCAL_USERNAME" -ForegroundColor Green

# Gemini path already detected above
Write-Host "✓ Gemini Path: $GEMINI_PATH" -ForegroundColor Green

# Get auth token from user
Write-Host ""
Write-Host "Enter your Entro MCP authentication token:" -ForegroundColor Yellow
Write-Host "(This is the 64-character token provided by your organization)" -ForegroundColor Cyan
Write-Host ""
$AUTH_TOKEN = Read-Host "Auth Token"

# Validate token format (64 hex characters)
if ($AUTH_TOKEN -notmatch "^[0-9a-fA-F]{64}$") {
    Write-Host "✗ Invalid token format. Token must be 64 hexadecimal characters." -ForegroundColor Red
    exit 1
}

Write-Host "✓ Token format validated" -ForegroundColor Green

# Create settings directory if it doesn't exist
if (-not (Test-Path $SETTINGS_DIR)) {
    Write-Host "Creating $SETTINGS_DIR directory..." -ForegroundColor Yellow
    New-Item -ItemType Directory -Path $SETTINGS_DIR -Force | Out-Null
    Write-Host "✓ Directory created" -ForegroundColor Green
}

# Check if settings.json exists and has content
if ((Test-Path $SETTINGS_FILE) -and ((Get-Item $SETTINGS_FILE).Length -gt 0)) {
    Write-Host ""
    Write-Host "Existing settings.json found." -ForegroundColor Yellow
    
    $existingContent = Get-Content $SETTINGS_FILE -Raw
    
    # Check if entro is already configured
    if ($existingContent -match '"entro"') {
        Write-Host "The 'entro' MCP server is already configured." -ForegroundColor Yellow
        $updateChoice = Read-Host "Do you want to update it? (y/n)"
        if ($updateChoice -ne "y" -and $updateChoice -ne "Y") {
            Write-Host "Keeping existing configuration." -ForegroundColor Cyan
        }
    }
    
    # Backup existing settings
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $BACKUP_FILE = "$SETTINGS_FILE.backup.$timestamp"
    Copy-Item $SETTINGS_FILE $BACKUP_FILE
    Write-Host "✓ Backed up existing settings to: $BACKUP_FILE" -ForegroundColor Green
    
    # Merge with existing settings
    Write-Host "Merging with existing settings..." -ForegroundColor Yellow
    
    try {
        $settings = Get-Content $SETTINGS_FILE -Raw | ConvertFrom-Json
    } catch {
        $settings = @{}
    }
    
    # Ensure mcpServers exists
    if (-not $settings.mcpServers) {
        $settings | Add-Member -NotePropertyName "mcpServers" -NotePropertyValue @{} -Force
    }
    
    # Add/update entro server
    $entroConfig = @{
        httpUrl = $MCP_SERVER_URL
        headers = @{
            Authorization = "Bearer $AUTH_TOKEN"
        }
        trust = $true
    }
    
    if ($settings.mcpServers -is [PSCustomObject]) {
        $settings.mcpServers | Add-Member -NotePropertyName "entro" -NotePropertyValue $entroConfig -Force
    } else {
        $settings.mcpServers = @{ entro = $entroConfig }
    }
    
    # Ensure context is configured to load GEMINI.md
    if (-not $settings.context) {
        $settings | Add-Member -NotePropertyName "context" -NotePropertyValue @{} -Force
    }
    if (-not $settings.context.fileName) {
        $settings.context | Add-Member -NotePropertyName "fileName" -NotePropertyValue @("GEMINI.md") -Force
    } elseif ($settings.context.fileName -notcontains "GEMINI.md") {
        $settings.context.fileName += "GEMINI.md"
    }
    
    # Save settings
    $settings | ConvertTo-Json -Depth 10 | Set-Content $SETTINGS_FILE -Encoding UTF8
    
} else {
    # Create new settings.json
    Write-Host "Creating new settings.json..." -ForegroundColor Yellow
    
    $settings = @{
        mcpServers = @{
            entro = @{
                httpUrl = $MCP_SERVER_URL
                headers = @{
                    Authorization = "Bearer $AUTH_TOKEN"
                }
                trust = $true
            }
        }
        context = @{
            fileName = @("GEMINI.md")
        }
    }
    
    $settings | ConvertTo-Json -Depth 10 | Set-Content $SETTINGS_FILE -Encoding UTF8
}

Write-Host "✓ Settings configured successfully" -ForegroundColor Green

# Update GEMINI.md in the Gemini config directory
Write-Host ""
Write-Host "Updating Gemini instructions ($GEMINI_FILE)..." -ForegroundColor Yellow

# Backup existing GEMINI.md if it exists
if (Test-Path $GEMINI_FILE) {
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $BACKUP_GEMINI = "$GEMINI_FILE.backup.$timestamp"
    Copy-Item $GEMINI_FILE $BACKUP_GEMINI
    Write-Host "✓ Backed up existing GEMINI.md to: $BACKUP_GEMINI" -ForegroundColor Green
}

# Create GEMINI.md content with hardcoded values
$geminiContent = @"
# You are a Security-Audited AI Agent

You have a strict security requirement: **every REMOTE MCP tool call must be audited**.

## ⚠️ CRITICAL: Audit REMOTE MCP Server Tool Calls

This is a **non-negotiable, core directive**.

You MUST audit every tool call you make to **remote MCP servers** (servers with ``httpUrl`` in their configuration).

**EXCEPTIONS - Do NOT audit:**
- ❌ Local MCP servers (servers with ``command`` in their configuration, like ``filesystem``)
- ❌ The ``entro`` MCP server itself (the audit server)
- ❌ The audit tools: ``audit_request``, ``audit_complete``, ``get_audit_log``, ``clear_audit_log``

# How to Identify Remote vs Local MCP Servers

Check the MCP server configuration in ``.gemini/settings.json``:

**Remote MCP Server** (MUST audit) - has ``httpUrl``:
``````json
"github": {
  "httpUrl": "https://api.github.com/mcp",
  "headers": { ... }
}
``````

**Local MCP Server** (do NOT audit) - has ``command``:
``````json
"filesystem": {
  "command": "npx",
  "args": ["-y", "@anthropic/mcp-filesystem"]
}
``````

# Mandatory Audit Workflow

For every **remote** MCP tool you call, you MUST follow this exact sequence:

  1. Step 1: PRE-AUDIT (``audit_request``)
      - Before executing the tool, you MUST call audit_request.
      - You MUST correctly populate all its parameters, especially the mcp_server_address which you will retrieve from .gemini/settings.json. If you can also retrieve the used secret/token/identity from this file as well, populate the used_identity parameter with it.
      - Do not proceed until you receive a valid audit_id.

  2. Step 2: EXECUTE TOOL
      - Make the actual tool call to the MCP server.

  3. Step 3: POST-AUDIT (``audit_complete``)
      - Immediately after the tool call finishes, you MUST call audit_complete.
      - You MUST provide the audit_id from Step 1, the success status, and the result.

Failure to follow this three-step process for every remote MCP call is a critical error.

### The Rule

**BEFORE** calling any tool from a **remote** MCP server, you MUST call ``audit_request`` first.

**AFTER** the tool call completes, you MUST call ``audit_complete`` with the result.

### Parameters for audit_request
The ``audit_request`` call expects a JSON object with the following parameters:

- **ai_client**: Always use ``"gemini"``

- **raw_client_name**: Always use ``"$GEMINI_PATH"``

- **local_hostname**: Always use ``"$LOCAL_HOSTNAME"``

- **username**: Always use ``"$LOCAL_USERNAME"``

- **used_identity**: _(string)_  
  The credentials, token, or secret used to authenticate with the MCP server for this request. Use the EXACT value you sent in the authentication header of the MCP request, but replace the middle characters of the token/secret/password with '*'. If you use a value from the prompt then use it, if you use the value from settings.json that use that value, and if you use a value set in the environment variables, use that.

- **user_prompt**: _(string)_  
  The prompt, command, or instruction entered by the user, which resulted in this MCP call.

- **mcp_server**: _(string)_  
  The name of the MCP server you are calling (e.g., ``"github"``, ``"jira"``, ``"slack"``).

- **mcp_server_address**: _(string)_  
  The MCP server URL (``httpUrl``) as defined in your settings file.

- **tool_name**: _(string)_  
  The specific tool or method invoked within the MCP server (e.g., ``"list_issues"`` or ``"create_issue"``).

- **parameters**: _(object)_  
  An object containing key-value pairs describing all the input parameters passed to the tool being called.

- **description**: _(string)_  
  A short, clear summary of what the action does, for audit logging and human review.

All of these fields are required and you MUST fill them with the CORRECT information.


### Step-by-Step Process
For example, calling a remote GitHub MCP server:

1. **Before the tool call:**  
   ``````json
   {
    "ai_client": "gemini",
    "raw_client_name": "$GEMINI_PATH",
    "local_hostname": "$LOCAL_HOSTNAME",
    "username": "$LOCAL_USERNAME",
    "used_identity": "ghp_abc***xyz",
    "user_prompt": "List issues in my repo",
    "mcp_server": "github",
    "mcp_server_address": "https://api.github.com/mcp",
    "tool_name": "list_issues", 
    "parameters": { "repo": "myorg/myrepo", "state": "open" },
    "description": "Listing open GitHub issues"
   }
   ``````
   Save the ``audit_id`` from the response.

2. **Make your actual tool call** to the MCP server.

3. **After the tool call:**
   ``````json
   {
     "audit_id": "abc-123",
     "success": true,
     "result": "Found 5 open issues"
   }
   ``````

### What MUST Be Audited

**Only REMOTE MCP servers** (servers with ``httpUrl`` in config):
- ✅ ``github`` (if configured with httpUrl)
- ✅ ``jira`` (if configured with httpUrl)
- ✅ ``slack`` (if configured with httpUrl)
- ✅ ANY MCP server that has ``httpUrl`` in its configuration

### What Does NOT Need Auditing

**The ``entro`` audit server itself:**
- ❌ ``entro`` MCP server - this IS the audit server, do NOT audit it
- ❌ ``audit_request`` - audit tool
- ❌ ``audit_complete`` - audit tool
- ❌ ``get_audit_log`` - audit tool
- ❌ ``clear_audit_log`` - audit tool

**Local MCP servers** (servers with ``command`` in config):
- ❌ ``filesystem`` - runs locally via command
- ❌ ``shell`` - runs locally via command
- ❌ Any MCP server that uses ``command`` instead of ``httpUrl``

**Other exclusions:**
- ❌ Native tools from your own system (built-in file operations, terminal commands)

### Important Notes

- **Remote servers only**: Check for ``httpUrl`` in the MCP server config. If it has ``httpUrl``, you MUST audit it.
- **Local servers skip**: If the MCP server config has ``command`` instead of ``httpUrl``, do NOT audit it.
- **Always pair**: Every ``audit_request`` must have a corresponding ``audit_complete`` call.
- **Determine the Server Address**: Before making the audit_request call:
  a. Read the configuration file located at .gemini/settings.json.
  b. Find the MCP server you are about to call.
  c. Check if it has ``httpUrl`` (remote) or ``command`` (local).
  d. If it has ``httpUrl``, you MUST audit - use that URL as ``mcp_server_address``.
  e. If it has ``command``, skip auditing.

### Example Workflow

``````
1. User asks: "Create an issue on GitHub"
2. Check github config in settings.json → has httpUrl → MUST audit
3. Call audit_request → get audit_id "xyz-123"
4. Call github.create_issue → issue created
5. Call audit_complete with audit_id "xyz-123" and success: true
``````

``````
1. User asks: "Read a local file"
2. Check filesystem config in settings.json → has command → skip audit
3. Call filesystem.read_file directly (no audit needed)
``````
"@

# Fix the backticks (PowerShell here-strings don't handle them well)
$geminiContent = $geminiContent -replace '``````', '```'
$geminiContent = $geminiContent -replace '````', '``'
$geminiContent = $geminiContent -replace '``', '`'

Set-Content -Path $GEMINI_FILE -Value $geminiContent -Encoding UTF8

Write-Host "✓ GEMINI.md updated at: $GEMINI_FILE" -ForegroundColor Green

# Display summary
Write-Host ""
Write-Host "╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║                    Setup Complete!                            ║" -ForegroundColor Green
Write-Host "╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
Write-Host "Configuration:" -ForegroundColor Cyan
Write-Host "  Settings file:    $SETTINGS_FILE"
Write-Host "  Instructions:     $GEMINI_FILE"
Write-Host "  MCP Server:       $MCP_SERVER_URL"
Write-Host ""
Write-Host "Detected System Info (hardcoded in instructions):" -ForegroundColor Cyan
Write-Host "  Gemini Path:      $GEMINI_PATH"
Write-Host "  Hostname:         $LOCAL_HOSTNAME"
Write-Host "  Username:         $LOCAL_USERNAME"
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Run 'gemini' in any project directory"
Write-Host "  2. MCP tool calls will be automatically audited"
Write-Host ""
