# Gemini CLI - Entro MCP Audit Setup

This guide explains how to configure Gemini CLI with the Entro MCP Audit Server.

## Prerequisites

Before running the setup script, ensure you have:

1. **Node.js 18+** installed
   - Check: `node --version`
   - Download: https://nodejs.org/

2. **Gemini CLI** installed
   ```bash
   npm install -g @google/gemini-cli
   ```

3. **Your Entro Auth Token** (64-character hex string)
   - Obtain from your Entro contact
   - Example format: `a1b2c3d4e5f6...` (64 characters)

---

## Installation

### Mac / Linux

Open Terminal and navigate to this folder, then run:

```bash
chmod +x setup.sh
./setup.sh
```

### Windows

Open PowerShell and navigate to this folder, then run:

```powershell
# Allow script execution (one-time, if needed)
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Run the script
.\setup.ps1
```

If you get a script execution error, run with bypass:

```powershell
powershell -ExecutionPolicy Bypass -File setup.ps1
```

---

## What the Setup Script Does

| Step | Description |
|------|-------------|
| 1 | ✅ Verify Gemini CLI is installed |
| 2 | ✅ Detect your system info (hostname, username, Gemini path) |
| 3 | ✅ Prompt for your Entro auth token |
| 4 | ✅ Validate token format (64-character hex) |
| 5 | ✅ Backup existing config files (if any) |
| 6 | ✅ Create/update `~/.gemini/settings.json` |
| 7 | ✅ Create/update `~/.gemini/GEMINI.md` with audit instructions |

### Files Created/Modified

| File | Purpose |
|------|---------|
| `~/.gemini/settings.json` | MCP server configuration with your auth token |
| `~/.gemini/GEMINI.md` | Instructions for Gemini to audit MCP calls |

### Backups

If existing files are found, they are backed up with a timestamp:
- `settings.json.backup.20260120_143022`
- `GEMINI.md.backup.20260120_143022`

---

## Example Output

```
╔══════════════════════════════════════════════════════════════╗
║          Entro MCP Audit Server - Gemini Setup               ║
╚══════════════════════════════════════════════════════════════╝

Checking for Gemini CLI...
✓ Gemini CLI found at: /opt/homebrew/bin/gemini

Detecting system information...
✓ Hostname: johns-macbook-pro
✓ Username: john
✓ Gemini Path: /opt/homebrew/bin/gemini

Enter your Entro MCP authentication token:
(This is the 64-character token provided by your organization)

Auth Token: ********************************
✓ Token format validated

Creating new settings.json...
✓ Settings configured successfully

Updating Gemini instructions...
✓ GEMINI.md updated at: /Users/john/.gemini/GEMINI.md

╔══════════════════════════════════════════════════════════════╗
║                    Setup Complete!                            ║
╚══════════════════════════════════════════════════════════════╝

Configuration:
  Settings file:    /Users/john/.gemini/settings.json
  Instructions:     /Users/john/.gemini/GEMINI.md
  MCP Server:       https://mcp.entro.security/mcp

Detected System Info (hardcoded in instructions):
  Gemini Path:      /opt/homebrew/bin/gemini
  Hostname:         johns-macbook-pro
  Username:         john

Next steps:
  1. Run 'gemini' in any project directory
  2. MCP tool calls will be automatically audited
```

---

## Verify Installation

After setup, verify the configuration:

### 1. Check settings.json

```bash
cat ~/.gemini/settings.json
```

Expected output:
```json
{
  "mcpServers": {
    "entro": {
      "httpUrl": "https://mcp.entro.security/mcp",
      "headers": {
        "Authorization": "Bearer your-token-here..."
      },
      "trust": true
    }
  },
  "context": {
    "fileName": ["GEMINI.md"]
  }
}
```

### 2. Check GEMINI.md

```bash
head -20 ~/.gemini/GEMINI.md
```

Should show audit instructions with your hardcoded system info.

### 3. Test Gemini

```bash
gemini
```

Then ask Gemini to make a **remote** MCP call (if you have remote MCP servers configured, like GitHub):
```
> List my GitHub issues
```

Verify that:
- `audit_request` is called before the tool
- `audit_complete` is called after the tool

**Note:** Only **remote** MCP servers (configured with `httpUrl`) are audited. Local MCP servers (configured with `command`, like `filesystem`) are NOT audited.

---

## Troubleshooting

### "Gemini CLI not found"

Install Gemini CLI:
```bash
npm install -g @google/gemini-cli
```

If npm is not found, install Node.js first: https://nodejs.org/

### "Invalid token format"

Your token must be exactly 64 hexadecimal characters (0-9, a-f).

Example valid token:
```
a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2
```

### "Permission denied" (Mac/Linux)

Make the script executable:
```bash
chmod +x setup.sh
```

### "Script execution disabled" (Windows)

Allow script execution:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

Or run with bypass:
```powershell
powershell -ExecutionPolicy Bypass -File setup.ps1
```

### Gemini not loading GEMINI.md instructions

1. Verify the file exists:
   ```bash
   ls -la ~/.gemini/GEMINI.md
   ```

2. Verify `settings.json` has the context configuration:
   ```json
   "context": {
     "fileName": ["GEMINI.md"]
   }
   ```

3. Restart Gemini CLI

---

## Uninstall

To remove the Entro MCP configuration:

### Mac / Linux
```bash
rm ~/.gemini/settings.json
rm ~/.gemini/GEMINI.md
```

### Windows (PowerShell)
```powershell
Remove-Item "$env:USERPROFILE\.gemini\settings.json"
Remove-Item "$env:USERPROFILE\.gemini\GEMINI.md"
```

---

## Support

For issues or questions, contact your Entro representative.
