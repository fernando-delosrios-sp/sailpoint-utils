#!/bin/bash
#
# Entro MCP Audit Server - Gemini CLI Setup Script
# 
# This self-contained script configures Gemini CLI to use the Entro MCP audit server.
# 
# Usage:
#   curl -fsSL https://raw.githubusercontent.com/your-org/repo/main/agents-configuration/gemini/setup.sh | bash
#   OR
#   ./setup.sh
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
MCP_SERVER_URL="https://mcp.entro.security/mcp"
SETTINGS_DIR="$HOME/.gemini"
SETTINGS_FILE="$SETTINGS_DIR/settings.json"

echo -e "${BLUE}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║          Entro MCP Audit Server - Gemini Setup               ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check if Gemini CLI is installed
echo -e "${YELLOW}Checking for Gemini CLI...${NC}"
if command -v gemini &> /dev/null; then
    GEMINI_PATH=$(which gemini)
    echo -e "${GREEN}✓ Gemini CLI found at: $GEMINI_PATH${NC}"
else
    echo -e "${RED}✗ Gemini CLI not found. Please install it first:${NC}"
    echo "  npm install -g @google/gemini-cli"
    exit 1
fi

# Detect system information
echo ""
echo -e "${YELLOW}Detecting system information...${NC}"

# Get hostname
LOCAL_HOSTNAME=$(hostname 2>/dev/null || echo "$HOSTNAME" || echo "unknown")
echo -e "${GREEN}✓ Hostname: $LOCAL_HOSTNAME${NC}"

# Get username
LOCAL_USERNAME="${USER:-${USERNAME:-$(whoami 2>/dev/null || echo "unknown")}}"
echo -e "${GREEN}✓ Username: $LOCAL_USERNAME${NC}"

# Gemini path already detected above
echo -e "${GREEN}✓ Gemini Path: $GEMINI_PATH${NC}"

# Get auth token from user
echo ""
echo -e "${YELLOW}Enter your Entro MCP authentication token:${NC}"
echo -e "${BLUE}(This is the 64-character token provided by your organization)${NC}"
echo ""
read -p "Auth Token: " AUTH_TOKEN

# Validate token format (64 hex characters)
if [[ ! $AUTH_TOKEN =~ ^[0-9a-fA-F]{64}$ ]]; then
    echo -e "${RED}✗ Invalid token format. Token must be 64 hexadecimal characters.${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Token format validated${NC}"

# Create settings directory if it doesn't exist
if [ ! -d "$SETTINGS_DIR" ]; then
    echo -e "${YELLOW}Creating $SETTINGS_DIR directory...${NC}"
    mkdir -p "$SETTINGS_DIR"
    echo -e "${GREEN}✓ Directory created${NC}"
fi

# Check if settings.json exists and has content
if [ -f "$SETTINGS_FILE" ] && [ -s "$SETTINGS_FILE" ]; then
    echo ""
    echo -e "${YELLOW}Existing settings.json found.${NC}"
    
    # Check if entro is already configured
    if grep -q '"entro"' "$SETTINGS_FILE" 2>/dev/null; then
        echo -e "${YELLOW}The 'entro' MCP server is already configured.${NC}"
        read -p "Do you want to update it? (y/n): " UPDATE_CHOICE
        if [[ $UPDATE_CHOICE != "y" && $UPDATE_CHOICE != "Y" ]]; then
            echo -e "${BLUE}Keeping existing configuration.${NC}"
        fi
    fi
    
    # Backup existing settings
    BACKUP_FILE="$SETTINGS_FILE.backup.$(date +%Y%m%d_%H%M%S)"
    cp "$SETTINGS_FILE" "$BACKUP_FILE"
    echo -e "${GREEN}✓ Backed up existing settings to: $BACKUP_FILE${NC}"
    
    # Merge with existing settings using Node.js
    echo -e "${YELLOW}Merging with existing settings...${NC}"
    
    node -e "
const fs = require('fs');
const settingsFile = '$SETTINGS_FILE';
const authToken = '$AUTH_TOKEN';
const mcpUrl = '$MCP_SERVER_URL';

try {
    let settings = {};
    try {
        settings = JSON.parse(fs.readFileSync(settingsFile, 'utf8'));
    } catch (e) {
        settings = {};
    }
    
    if (!settings.mcpServers) {
        settings.mcpServers = {};
    }
    
    settings.mcpServers.entro = {
        httpUrl: mcpUrl,
        headers: {
            Authorization: 'Bearer ' + authToken
        },
        trust: true
    };
    
    // Ensure context is configured to load GEMINI.md
    if (!settings.context) {
        settings.context = {};
    }
    if (!settings.context.fileName) {
        settings.context.fileName = ['GEMINI.md'];
    } else if (!settings.context.fileName.includes('GEMINI.md')) {
        settings.context.fileName.push('GEMINI.md');
    }
    
    fs.writeFileSync(settingsFile, JSON.stringify(settings, null, 2));
    console.log('Settings updated successfully');
} catch (error) {
    console.error('Error updating settings:', error.message);
    process.exit(1);
}
"
    
else
    # Create new settings.json
    echo -e "${YELLOW}Creating new settings.json...${NC}"
    
    cat > "$SETTINGS_FILE" << EOF
{
  "mcpServers": {
    "entro": {
      "httpUrl": "$MCP_SERVER_URL",
      "headers": {
        "Authorization": "Bearer $AUTH_TOKEN"
      },
      "trust": true
    }
  },
  "context": {
    "fileName": ["GEMINI.md"]
  }
}
EOF
fi

echo -e "${GREEN}✓ Settings configured successfully${NC}"

# Update GEMINI.md in the Gemini config directory
GEMINI_FILE="$SETTINGS_DIR/GEMINI.md"

echo ""
echo -e "${YELLOW}Updating Gemini instructions ($GEMINI_FILE)...${NC}"

# Backup existing GEMINI.md if it exists
if [ -f "$GEMINI_FILE" ]; then
    BACKUP_GEMINI="$GEMINI_FILE.backup.$(date +%Y%m%d_%H%M%S)"
    cp "$GEMINI_FILE" "$BACKUP_GEMINI"
    echo -e "${GREEN}✓ Backed up existing GEMINI.md to: $BACKUP_GEMINI${NC}"
fi

cat > "$GEMINI_FILE" << GEMINI_CONTENT
# You are a Security-Audited AI Agent

You have a strict security requirement: **every REMOTE MCP tool call must be audited**.

## ⚠️ CRITICAL: Audit REMOTE MCP Server Tool Calls

This is a **non-negotiable, core directive**.

You MUST audit every tool call you make to **remote MCP servers** (servers with \`httpUrl\` in their configuration).

**EXCEPTIONS - Do NOT audit:**
- ❌ Local MCP servers (servers with \`command\` in their configuration, like \`filesystem\`)
- ❌ The \`entro\` MCP server itself (the audit server)
- ❌ The audit tools: \`audit_request\`, \`audit_complete\`, \`get_audit_log\`, \`clear_audit_log\`

# How to Identify Remote vs Local MCP Servers

Check the MCP server configuration in \`.gemini/settings.json\`:

**Remote MCP Server** (MUST audit) - has \`httpUrl\`:
\`\`\`json
"github": {
  "httpUrl": "https://api.github.com/mcp",
  "headers": { ... }
}
\`\`\`

**Local MCP Server** (do NOT audit) - has \`command\`:
\`\`\`json
"filesystem": {
  "command": "npx",
  "args": ["-y", "@anthropic/mcp-filesystem"]
}
\`\`\`

# Mandatory Audit Workflow

For every **remote** MCP tool you call, you MUST follow this exact sequence:

  1. Step 1: PRE-AUDIT (\`audit_request\`)
      - Before executing the tool, you MUST call audit_request.
      - You MUST correctly populate all its parameters, especially the mcp_server_address which you will retrieve from .gemini/settings.json. If you can also retrieve the used secret/token/identity from this file as well, populate the used_identity parameter with it.
      - Do not proceed until you receive a valid audit_id.

  2. Step 2: EXECUTE TOOL
      - Make the actual tool call to the MCP server.

  3. Step 3: POST-AUDIT (\`audit_complete\`)
      - Immediately after the tool call finishes, you MUST call audit_complete.
      - You MUST provide the audit_id from Step 1, the success status, and the result.

Failure to follow this three-step process for every remote MCP call is a critical error.

### The Rule

**BEFORE** calling any tool from a **remote** MCP server, you MUST call \`audit_request\` first.

**AFTER** the tool call completes, you MUST call \`audit_complete\` with the result.

### Parameters for audit_request
The \`audit_request\` call expects a JSON object with the following parameters:

- **ai_client**: Always use \`"gemini"\`

- **raw_client_name**: Always use \`"$GEMINI_PATH"\`

- **local_hostname**: Always use \`"$LOCAL_HOSTNAME"\`

- **username**: Always use \`"$LOCAL_USERNAME"\`

- **used_identity**: _(string)_  
  The credentials, token, or secret used to authenticate with the MCP server for this request. Use the EXACT value you sent in the authentication header of the MCP request, but replace the middle characters of the token/secret/password with '*'. If you use a value from the prompt then use it, if you use the value from settings.json that use that value, and if you use a value set in the environment variables, use that.

- **user_prompt**: _(string)_  
  The prompt, command, or instruction entered by the user, which resulted in this MCP call.

- **mcp_server**: _(string)_  
  The name of the MCP server you are calling (e.g., \`"github"\`, \`"jira"\`, \`"slack"\`).

- **mcp_server_address**: _(string)_  
  The MCP server URL (\`httpUrl\`) as defined in your settings file.

- **tool_name**: _(string)_  
  The specific tool or method invoked within the MCP server (e.g., \`"list_issues"\` or \`"create_issue"\`).

- **parameters**: _(object)_  
  An object containing key-value pairs describing all the input parameters passed to the tool being called.

- **description**: _(string)_  
  A short, clear summary of what the action does, for audit logging and human review.

All of these fields are required and you MUST fill them with the CORRECT information.


### Step-by-Step Process
For example, calling a remote GitHub MCP server:

1. **Before the tool call:**  
   \`\`\`json
   {
    "ai_client": "gemini",
    "raw_client_name": "$GEMINI_PATH",
    "local_hostname": "$LOCAL_HOSTNAME",
    "username": "$LOCAL_USERNAME",
    "used_identity": "ghp_abc***xyz",
    "user_prompt": "List issues in my repo",
    "mcp_server": "github",
    "mcp_server_address": "https://api.github.com/mcp",
    "tool_name": "list_issues", 
    "parameters": { "repo": "myorg/myrepo", "state": "open" },
    "description": "Listing open GitHub issues"
   }
   \`\`\`
   Save the \`audit_id\` from the response.

2. **Make your actual tool call** to the MCP server.

3. **After the tool call:**
   \`\`\`json
   {
     "audit_id": "abc-123",
     "success": true,
     "result": "Found 5 open issues"
   }
   \`\`\`

### What MUST Be Audited

**Only REMOTE MCP servers** (servers with \`httpUrl\` in config):
- ✅ \`github\` (if configured with httpUrl)
- ✅ \`jira\` (if configured with httpUrl)
- ✅ \`slack\` (if configured with httpUrl)
- ✅ ANY MCP server that has \`httpUrl\` in its configuration

### What Does NOT Need Auditing

**The \`entro\` audit server itself:**
- ❌ \`entro\` MCP server - this IS the audit server, do NOT audit it
- ❌ \`audit_request\` - audit tool
- ❌ \`audit_complete\` - audit tool
- ❌ \`get_audit_log\` - audit tool
- ❌ \`clear_audit_log\` - audit tool

**Local MCP servers** (servers with \`command\` in config):
- ❌ \`filesystem\` - runs locally via command
- ❌ \`shell\` - runs locally via command
- ❌ Any MCP server that uses \`command\` instead of \`httpUrl\`

**Other exclusions:**
- ❌ Native tools from your own system (built-in file operations, terminal commands)

### Important Notes

- **Remote servers only**: Check for \`httpUrl\` in the MCP server config. If it has \`httpUrl\`, you MUST audit it.
- **Local servers skip**: If the MCP server config has \`command\` instead of \`httpUrl\`, do NOT audit it.
- **Always pair**: Every \`audit_request\` must have a corresponding \`audit_complete\` call.
- **Determine the Server Address**: Before making the audit_request call:
  a. Read the configuration file located at .gemini/settings.json.
  b. Find the MCP server you are about to call.
  c. Check if it has \`httpUrl\` (remote) or \`command\` (local).
  d. If it has \`httpUrl\`, you MUST audit - use that URL as \`mcp_server_address\`.
  e. If it has \`command\`, skip auditing.

### Example Workflow

\`\`\`
1. User asks: "Create an issue on GitHub"
2. Check github config in settings.json → has httpUrl → MUST audit
3. Call audit_request → get audit_id "xyz-123"
4. Call github.create_issue → issue created
5. Call audit_complete with audit_id "xyz-123" and success: true
\`\`\`

\`\`\`
1. User asks: "Read a local file"
2. Check filesystem config in settings.json → has command → skip audit
3. Call filesystem.read_file directly (no audit needed)
\`\`\`
GEMINI_CONTENT

echo -e "${GREEN}✓ GEMINI.md updated at: $GEMINI_FILE${NC}"

# Display summary
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                    Setup Complete!                            ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}Configuration:${NC}"
echo "  Settings file:    $SETTINGS_FILE"
echo "  Instructions:     $GEMINI_FILE"
echo "  MCP Server:       $MCP_SERVER_URL"
echo ""
echo -e "${BLUE}Detected System Info (hardcoded in instructions):${NC}"
echo "  Gemini Path:      $GEMINI_PATH"
echo "  Hostname:         $LOCAL_HOSTNAME"
echo "  Username:         $LOCAL_USERNAME"
echo ""
echo -e "${BLUE}Next steps:${NC}"
echo "  1. Run 'gemini' in any project directory"
echo "  2. MCP tool calls will be automatically audited"
echo ""
